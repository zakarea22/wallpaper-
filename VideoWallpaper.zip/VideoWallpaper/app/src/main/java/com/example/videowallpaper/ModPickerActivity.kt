package com.example.videowallpaper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp

/**
 * الغرض: قائمة الأوضاع التي تظهر عند الضغط المطول على زر الإعدادات السريعة.
 * نافذة شفافة بلا واجهة خلفها (الثيم الشفاف في المانيفست)، تعرض LazyColumn عمودياً:
 * الصورة المصغرة + الاسم الكامل + حالة "النشط". الضغط على وضع يطبّقه ويغلق النافذة.
 */
class ModPickerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme(withBackground = false) {
                ModPickerDialog(onDone = { finish() })
            }
        }
    }
}

@Composable
private fun ModPickerDialog(onDone: () -> Unit) {
    val context = LocalContext.current
    val mods = remember { ModStore.list(context) }
    val activeId = remember { ModStore.activeId(context) }

    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(stringResource(R.string.mods_pick_title)) },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                items(mods, key = { it.id }) { mod ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                ModStore.apply(context, mod.id)
                                onDone()
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ModThumb(mod = mod, size = 52.dp)
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 12.dp)
                        ) {
                            Text(text = mod.name, style = MaterialTheme.typography.titleMedium)
                            if (mod.id == activeId) {
                                Text(
                                    text = stringResource(R.string.mods_active),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDone) { Text(stringResource(R.string.mods_close)) }
        }
    )
}
