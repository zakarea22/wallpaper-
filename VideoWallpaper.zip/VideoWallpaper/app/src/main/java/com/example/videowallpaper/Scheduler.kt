package com.example.videowallpaper

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

/**
 * الغرض: التبديل التلقائي بين وضعين (نهار / ليل) حسب الساعة.
 * يستخدم منبّهاً غير دقيق (setAndAllowWhileIdle) لا يحتاج صلاحية خاصة ولا يستهلك بطارية تُذكر:
 * منبّه واحد فقط في كل مرة، يُعاد ضبطه بعد كل تنفيذ وبعد إعادة التشغيل أو تحديث التطبيق.
 */
object Scheduler {

    const val ACTION_FIRE = "com.example.videowallpaper.SCHEDULE_FIRE"
    private const val REQUEST_CODE = 4711

    private fun isDay(hour: Int, dayHour: Int, nightHour: Int): Boolean =
        if (dayHour < nightHour) hour in dayHour until nightHour
        else hour >= dayHour || hour < nightHour

    /** الوضع المطلوب الآن حسب الجدول، أو null إن كان الجدول معطّلاً أو غير مكتمل. */
    fun targetModId(context: Context): String? {
        if (!AppSettings.schedEnabled(context)) return null
        val day = AppSettings.schedDayHour(context)
        val night = AppSettings.schedNightHour(context)
        if (day == night) return null
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val id = if (isDay(hour, day, night)) AppSettings.schedDayMod(context)
        else AppSettings.schedNightMod(context)
        return id?.takeIf { wanted -> ModStore.list(context).any { it.id == wanted } }
    }

    /** يطبّق وضع الفترة الحالية إن اختلف عن النشط. */
    fun applyNow(context: Context) {
        val id = targetModId(context) ?: return
        if (id != ModStore.activeId(context)) {
            AppLog.d(context, "Scheduler", "switch to $id")
            ModStore.apply(context, id)
        }
    }

    /** يضبط المنبّه التالي (أقرب بداية نهار أو ليل) أو يلغيه إن كان الجدول معطّلاً. */
    fun rearm(context: Context) {
        val app = context.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pi = pending(app)
        val day = AppSettings.schedDayHour(app)
        val night = AppSettings.schedNightHour(app)
        if (!AppSettings.schedEnabled(app) || day == night) {
            am.cancel(pi)
            return
        }
        val next = minOf(nextOccurrence(day), nextOccurrence(night))
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
    }

    private fun nextOccurrence(hour: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, hour)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis() + 1000) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    private fun pending(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context,
        REQUEST_CODE,
        Intent(context, ScheduleReceiver::class.java).setAction(ACTION_FIRE),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

/** يستقبل المنبّه، وإعادة التشغيل/التحديث/تغيّر الوقت: يعيد ضبط المنبّه، وبعد الإقلاع/التحديث يعيد رسم الويدجتات. */
class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pending = goAsync()
        Thread {
            try {
                when (intent.action) {
                    Scheduler.ACTION_FIRE -> {
                        Scheduler.applyNow(app)
                        ModStore.awaitRefresh()
                    }
                    // بعد اكتمال الإقلاع أو تحديث التطبيق: نعيد رسم كل الويدجتات كي لا تبقى فارغة
                    Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                        BootRefresh.refreshAll(app)
                        ModStore.awaitRefresh()
                    }
                }
                Scheduler.rearm(app)
            } catch (t: Throwable) {
                AppLog.d(app, "Scheduler", "error $t")
            } finally {
                pending.finish()
            }
        }.start()
    }
}
