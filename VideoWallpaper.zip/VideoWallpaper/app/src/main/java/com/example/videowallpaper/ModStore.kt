package com.example.videowallpaper

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import kotlin.math.min

/**
 * وضع (Mod) واحد: اسم + صورة مصغرة + خلفية متحركة.
 * محتوى الويدجتات لكل وضع يُخزَّن في WidgetStore تحت معرّف الوضع.
 */
data class Mod(
    val id: String,
    val name: String,
    /** 0 = بلا صورة مصغرة، وإلا وقت آخر تحديث (لتجديد التخزين المؤقت في الواجهة). */
    val thumbStamp: Long,
    val wallpaper: Uri?
)

/**
 * الغرض: مصدر الحقيقة للأوضاع والوضع النشط.
 *
 * الأداء:
 *  - التبديل (apply) يكتب قيمة صغيرة في SharedPreferences فتلتقطها خدمة الخلفية فوراً.
 *  - إعادة رسم الويدجتات تتم على خيط خلفي واحد مشترك (يموت تلقائياً بعد 10 ثوانٍ خمولاً)،
 *    فلا يتأخر الـ Tile ولا واجهة النظام، والطلبات المتتالية تُنفَّذ بالترتيب فتنتهي الحالة على آخر وضع.
 *  - لا نحتفظ بأي Context أو Bitmap في الذاكرة: كله يُقرأ من القرص عند الحاجة.
 */
object ModStore {

    const val DEFAULT_ID = "default"
    const val MAX_NAME_LENGTH = 30

    private const val TAG = "ModStore"
    private const val PREFS = "mod_store"
    private const val KEY_MODS = "mods"
    private const val KEY_ACTIVE = "active"
    private const val THUMB_SIZE = 256

    private val executor = ThreadPoolExecutor(
        1, 1, 10L, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>()
    ).apply { allowCoreThreadTimeOut(true) }

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ------------------------------------------------------------------ القراءة

    /** كل الأوضاع بالترتيب (من الأعلى للأسفل). يُنشئ وضعاً افتراضياً عند أول استخدام. */
    @Synchronized
    fun list(context: Context): List<Mod> {
        val app = context.applicationContext
        val p = prefs(app)
        val parsed = parse(p.getString(KEY_MODS, null))
        if (parsed.isNotEmpty()) return parsed
        val first = Mod(
            DEFAULT_ID,
            app.getString(R.string.mod_default_name),
            0L,
            WallpaperPrefs(app).getActiveVideo()
        )
        write(p, listOf(first))
        return listOf(first)
    }

    @Synchronized
    fun activeId(context: Context): String {
        val mods = list(context)
        val saved = prefs(context).getString(KEY_ACTIVE, null)
        return mods.firstOrNull { it.id == saved }?.id ?: mods.first().id
    }

    @Synchronized
    fun active(context: Context): Mod {
        val id = activeId(context)
        return list(context).first { it.id == id }
    }

    /** الوضع التالي بعد النشط (دائري). */
    @Synchronized
    fun next(context: Context): Mod {
        val mods = list(context)
        val current = activeId(context)
        val index = mods.indexOfFirst { it.id == current }
        return mods[(index + 1).mod(mods.size)]
    }

    // ------------------------------------------------------------------ التبديل

    /**
     * يجعل الوضع نشطاً: يغيّر الفيديو النشط للخلفية الحية (تلتقطه الخدمة فوراً إن كانت هي الخلفية الحالية)،
     * ثم يعيد رسم الويدجتات في الخلفية.
     */
    @Synchronized
    fun apply(context: Context, id: String) {
        val app = context.applicationContext
        val mod = list(app).firstOrNull { it.id == id } ?: return
        AppLog.d(app, "ModStore", "apply id=$id name=${mod.name} wallpaper=${mod.wallpaper}")
        prefs(app).edit().putString(KEY_ACTIVE, id).apply()
        mod.wallpaper?.let { WallpaperPrefs(app).setActiveVideo(it) }
        refreshWidgets(app)
    }

    /** يعيد رسم كل الويدجتات حسب الوضع النشط (على الخيط الخلفي المشترك). */
    fun refreshWidgets(context: Context) {
        val app = context.applicationContext
        executor.execute {
            try {
                val manager = AppWidgetManager.getInstance(app)
                val ids = manager.getAppWidgetIds(ComponentName(app, MediaWidgetProvider::class.java)) +
                    manager.getAppWidgetIds(ComponentName(app, ShortcutWidgetProvider::class.java))
                ids.forEach { WidgetRenderer.update(app, manager, it) }
            } catch (t: Throwable) {
                Log.w(TAG, "refreshWidgets failed", t)
            }
        }
    }

    // ------------------------------------------------------------------ التعديل

    /**
     * ينشئ وضعاً جديداً. عمل ثقيل (نسخ ملفات): استدعِه من خيط خلفي.
     * الأعمال الثقيلة تتم خارج القفل كي لا يتجمد الـ Tile أو الواجهة أثناءها.
     */
    fun create(context: Context, name: String, cloneActive: Boolean, thumb: Uri?): Mod {
        val app = context.applicationContext
        val source = active(app)
        val id = "m" + java.lang.Long.toString(System.currentTimeMillis(), 36)
        val clean = name.trim().take(MAX_NAME_LENGTH).ifEmpty { app.getString(R.string.mod_unnamed) }

        var stamp = 0L
        if (thumb != null && writeThumb(app, id, thumb)) stamp = System.currentTimeMillis()
        if (cloneActive) WidgetStore.cloneMod(app, source.id, id)

        val mod = Mod(id, clean, stamp, if (cloneActive) source.wallpaper else null)
        synchronized(this) { write(prefs(app), list(app) + mod) }
        return mod
    }

    @Synchronized
    fun rename(context: Context, id: String, name: String) {
        val clean = name.trim().take(MAX_NAME_LENGTH)
        if (clean.isEmpty()) return
        update(context, id) { it.copy(name = clean) }
    }

    /** يضبط الصورة المصغرة من صورة/فيديو. استدعِه من خيط خلفي. */
    fun setThumb(context: Context, id: String, uri: Uri): Boolean {
        val app = context.applicationContext
        if (!writeThumb(app, id, uri)) return false
        synchronized(this) { update(app, id) { it.copy(thumbStamp = System.currentTimeMillis()) } }
        return true
    }

    @Synchronized
    fun setWallpaper(context: Context, id: String, uri: Uri?) {
        update(context, id) { it.copy(wallpaper = uri) }
    }

    /** يزيل أي إشارة لفيديو حُذف من المكتبة. */
    @Synchronized
    fun clearWallpaper(context: Context, uri: Uri) {
        val app = context.applicationContext
        write(prefs(app), list(app).map { if (it.wallpaper == uri) it.copy(wallpaper = null) else it })
    }

    /** يحذف وضعاً (لا يمكن حذف الأخير). يُرجع false إن لم يُحذف. استدعِه من خيط خلفي. */
    fun delete(context: Context, id: String): Boolean {
        val app = context.applicationContext
        val wasActive: Boolean
        synchronized(this) {
            val mods = list(app)
            if (mods.size <= 1 || mods.none { it.id == id }) return false
            wasActive = activeId(app) == id
            write(prefs(app), mods.filter { it.id != id })
        }
        // الحذف الثقيل للملفات خارج القفل
        thumbFile(app, id).delete()
        WidgetStore.deleteMod(app, id)
        if (wasActive) apply(app, list(app).first().id)
        return true
    }

    // ------------------------------------------------------------------ الصور المصغرة

    fun thumbFile(context: Context, id: String): File =
        File(context.applicationContext.filesDir, "mod_thumbs/$id.jpg")

    /** يقرأ الصورة المصغرة من القرص (صغيرة 256px). */
    fun loadThumb(context: Context, mod: Mod): Bitmap? {
        if (mod.thumbStamp == 0L) return null
        return BitmapFactory.decodeFile(thumbFile(context, mod.id).path)
    }

    private fun writeThumb(context: Context, id: String, src: Uri): Boolean {
        val raw = FrameExtractor.thumbnail(context, src, 512) ?: return false
        val side = min(raw.width, raw.height)
        if (side <= 0) return false
        return try {
            val square = Bitmap.createBitmap(raw, (raw.width - side) / 2, (raw.height - side) / 2, side, side)
            val scaled = Bitmap.createScaledBitmap(square, THUMB_SIZE, THUMB_SIZE, true)
            val file = thumbFile(context, id)
            file.parentFile?.mkdirs()
            FileOutputStream(file).use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        } catch (e: Exception) {
            Log.w(TAG, "thumb write failed", e)
            false
        }
    }

    // ------------------------------------------------------------------ التخزين

    private fun update(context: Context, id: String, transform: (Mod) -> Mod) {
        val app = context.applicationContext
        write(prefs(app), list(app).map { if (it.id == id) transform(it) else it })
    }

    private fun parse(raw: String?): List<Mod> {
        if (raw.isNullOrEmpty()) return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.optJSONObject(i) ?: continue
                    val id = o.optString("id")
                    if (id.isEmpty()) continue
                    add(
                        Mod(
                            id = id,
                            name = o.optString("name"),
                            thumbStamp = o.optLong("thumb", 0L),
                            wallpaper = o.optString("wp").takeIf { it.isNotEmpty() }?.let { Uri.parse(it) }
                        )
                    )
                }
            }
        } catch (e: JSONException) {
            emptyList()
        }
    }

    private fun write(p: SharedPreferences, mods: List<Mod>) {
        val array = JSONArray()
        mods.forEach { m ->
            val o = JSONObject()
                .put("id", m.id)
                .put("name", m.name)
                .put("thumb", m.thumbStamp)
            m.wallpaper?.let { o.put("wp", it.toString()) }
            array.put(o)
        }
        p.edit().putString(KEY_MODS, array.toString()).apply()
    }
}
