package com.example.videowallpaper

import android.content.Context
import android.net.Uri
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * الغرض: سجل أحداث بسيط داخل التطبيق لتشخيص الأخطاء، يُصدَّر لمكان يختاره المستخدم.
 *
 * - يسجّل أحداثاً قليلة فقط (تشغيل الخلفية، تبديل الأوضاع، رسم الويدجتات، الأخطاء).
 * - الكتابة على خيط خلفي واحد، والحجم محدود (ملف حالي + ملف قديم) فلا يكبر ولا يبطّئ شيئاً.
 * - لا يُرسَل أي شيء تلقائياً: المستخدم هو من يصدّر الملف ويرسله.
 */
object AppLog {

    private const val TAG = "AppLog"
    private const val MAX_BYTES = 300_000L

    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "AppLog").apply { isDaemon = true }
    }
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)

    private fun current(context: Context) = File(context.applicationContext.filesDir, "app.log")
    private fun old(context: Context) = File(context.applicationContext.filesDir, "app.log.old")

    /** يضيف سطراً. آمن للاستدعاء من أي خيط. */
    fun d(context: Context, source: String, message: String) {
        val app = context.applicationContext
        val line = "${fmt.format(Date())} [$source] $message\n"
        Log.d(TAG, "[$source] $message")
        executor.execute {
            try {
                val f = current(app)
                if (f.length() > MAX_BYTES) {
                    val o = old(app)
                    o.delete()
                    f.renameTo(o)
                }
                f.appendText(line)
            } catch (_: Throwable) {
            }
        }
    }

    /** يكتب السجل (القديم ثم الحالي) مع معلومات الجهاز إلى الـ Uri الذي اختاره المستخدم. */
    fun exportTo(context: Context, uri: Uri): Boolean {
        val app = context.applicationContext
        return try {
            // ننتظر انتهاء الكتابات المعلّقة
            executor.submit { }.get()
            app.contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { w ->
                val info = app.packageManager.getPackageInfo(app.packageName, 0)
                w.write("App: ${app.packageName} ${info.versionName}\n")
                w.write("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n")
                w.write("Brand/Display: ${Build.BRAND} / ${Build.DISPLAY}\n\n")
                listOf(old(app), current(app)).filter { it.exists() }.forEach { w.write(it.readText()) }
            } != null
        } catch (t: Throwable) {
            Log.w(TAG, "export failed", t)
            false
        }
    }
}
