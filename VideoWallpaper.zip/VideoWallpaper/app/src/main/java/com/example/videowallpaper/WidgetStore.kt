package com.example.videowallpaper

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * إعدادات ويدجت واحد: مصدر الوسائط، عدد الإطارات المحفوظة، التطبيق الهدف، والاسم الاختياري.
 */
data class WidgetConfig(
    val widgetId: Int,
    val sourceUri: String,
    /** "image" أو "gif" أو "video" */
    val kind: String,
    val frameCount: Int,
    val hasAlpha: Boolean,
    /** 0 = أوضح، 1 = متوازن، 2 = أسلس */
    val quality: Int,
    val appPackage: String?,
    val label: String?
)

/**
 * الغرض: حفظ إعدادات كل ويدجت (SharedPreferences) وإدارة مجلدات الإطارات المخزّنة.
 */
object WidgetStore {

    private const val PREFS = "widget_store"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun get(context: Context, id: Int): WidgetConfig? {
        val raw = prefs(context).getString("w_$id", null) ?: return null
        return try {
            val o = JSONObject(raw)
            WidgetConfig(
                widgetId = id,
                sourceUri = o.getString("src"),
                kind = o.optString("kind", "image"),
                frameCount = o.optInt("frames", 1).coerceAtLeast(1),
                hasAlpha = o.optBoolean("alpha", false),
                quality = o.optInt("quality", 1).coerceIn(0, 2),
                appPackage = o.optString("pkg").takeIf { it.isNotEmpty() },
                label = o.optString("label").takeIf { it.isNotEmpty() }
            )
        } catch (e: Exception) {
            null
        }
    }

    fun save(context: Context, cfg: WidgetConfig) {
        val o = JSONObject()
            .put("src", cfg.sourceUri)
            .put("kind", cfg.kind)
            .put("frames", cfg.frameCount)
            .put("alpha", cfg.hasAlpha)
            .put("quality", cfg.quality)
        cfg.appPackage?.let { o.put("pkg", it) }
        cfg.label?.let { o.put("label", it) }
        prefs(context).edit().putString("w_${cfg.widgetId}", o.toString()).apply()
    }

    /** يمسح إعدادات الويدجت وإطاراته المخزّنة. */
    fun delete(context: Context, id: Int) {
        prefs(context).edit().remove("w_$id").apply()
        framesDir(context, id).deleteRecursively()
        tempDir(context, id).deleteRecursively()
    }

    fun framesDir(context: Context, id: Int): File =
        File(context.applicationContext.filesDir, "widget_frames/$id")

    fun tempDir(context: Context, id: Int): File =
        File(context.applicationContext.filesDir, "widget_frames/${id}_tmp")
}
