package com.example.videowallpaper

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * إعدادات ويدجت واحد: مصدر الوسائط، عدد الإطارات المحفوظة، التطبيق الهدف، والاسم الاختياري.
 */
data class WidgetConfig(
    val widgetId: Int,
    val sourceUri: String,
    /** "image" أو "gif" أو "video" */
    val kind: String,
    val frameCount: Int,
    val hasAlpha: Boolean,
    /** 0 = أوضح، 1 = متوازن، 2 = أسلس */
    val quality: Int,
    val appPackage: String?,
    val label: String?
)

/**
 * الغرض: حفظ محتوى كل ويدجت **لكل وضع (Mod)** وإدارة مجلدات الإطارات المخزّنة.
 *
 * المفتاح:  w_{modId}_{widgetId}      الإطارات:  files/widget_frames/{modId}/{widgetId}
 * معرّفات الأوضاع لا تحتوي على "_" فلا يحدث تداخل بين المفاتيح.
 * الدوال التي تأخذ mod تستخدم الوضع النشط افتراضياً.
 */
object WidgetStore {

    private const val PREFS = "widget_store"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(mod: String, id: Int) = "w_${mod}_$id"
    private fun hiddenKey(mod: String, id: Int) = "h_${mod}_$id"

    /** هل الويدجت مخفي في هذا الوضع؟ (يُرسم شفافاً وفارغاً دون أي إطارات) */
    fun isHidden(context: Context, id: Int, mod: String = ModStore.activeId(context)): Boolean =
        prefs(context).getBoolean(hiddenKey(mod, id), false)

    fun setHidden(context: Context, id: Int, hidden: Boolean, mod: String = ModStore.activeId(context)) {
        val e = prefs(context).edit()
        if (hidden) e.putBoolean(hiddenKey(mod, id), true) else e.remove(hiddenKey(mod, id))
        e.apply()
    }

    private fun root(context: Context) =
        File(context.applicationContext.filesDir, "widget_frames")

    fun get(context: Context, id: Int, mod: String = ModStore.activeId(context)): WidgetConfig? {
        val raw = prefs(context).getString(key(mod, id), null) ?: return null
        return try {
            val o = JSONObject(raw)
            WidgetConfig(
                widgetId = id,
                sourceUri = o.getString("src"),
                kind = o.optString("kind", "image"),
                frameCount = o.optInt("frames", 1).coerceAtLeast(1),
                hasAlpha = o.optBoolean("alpha", false),
                quality = o.optInt("quality", 1).coerceIn(0, 2),
                appPackage = o.optString("pkg").takeIf { it.isNotEmpty() },
                label = o.optString("label").takeIf { it.isNotEmpty() }
            )
        } catch (e: Exception) {
            null
        }
    }

    fun save(context: Context, cfg: WidgetConfig, mod: String = ModStore.activeId(context)) {
        val o = JSONObject()
            .put("src", cfg.sourceUri)
            .put("kind", cfg.kind)
            .put("frames", cfg.frameCount)
            .put("alpha", cfg.hasAlpha)
            .put("quality", cfg.quality)
        cfg.appPackage?.let { o.put("pkg", it) }
        cfg.label?.let { o.put("label", it) }
        prefs(context).edit().putString(key(mod, cfg.widgetId), o.toString()).apply()
    }

    /** يمسح محتوى الويدجت في وضع معيّن (الويدجت نفسه يبقى على الشاشة فارغاً). */
    fun delete(context: Context, id: Int, mod: String = ModStore.activeId(context)) {
        prefs(context).edit().remove(key(mod, id)).apply()
        framesDir(context, id, mod).deleteRecursively()
        tempDir(context, id, mod).deleteRecursively()
    }

    /** يُستدعى عند إزالة الويدجت من الشاشة: يمسح محتواه من كل الأوضاع. */
    fun deleteAllFor(context: Context, id: Int) {
        val p = prefs(context)
        val suffix = "_$id"
        val editor = p.edit()
        p.all.keys
            .filter { (it.startsWith("w_") || it.startsWith("h_")) && it.endsWith(suffix) }
            .forEach { editor.remove(it) }
        editor.apply()
        root(context).listFiles()?.forEach { modDir ->
            File(modDir, "$id").deleteRecursively()
            File(modDir, "${id}_tmp").deleteRecursively()
        }
    }

    /** ينسخ محتوى كل الويدجتات من وضع إلى وضع جديد (إعدادات + إطارات). */
    fun cloneMod(context: Context, from: String, to: String) {
        val p = prefs(context)
        val prefix = "w_${from}_"
        val editor = p.edit()
        val hPrefix = "h_${from}_"
        p.all.forEach { (k, v) ->
            if (k.startsWith(prefix) && v is String) {
                editor.putString("w_${to}_" + k.removePrefix(prefix), v)
            } else if (k.startsWith(hPrefix) && v is Boolean) {
                editor.putBoolean("h_${to}_" + k.removePrefix(hPrefix), v)
            }
        }
        editor.apply()
        val src = File(root(context), from)
        if (src.exists()) src.copyRecursively(File(root(context), to), overwrite = true)
    }

    /** يحذف كل محتوى وضع (عند حذفه). */
    fun deleteMod(context: Context, mod: String) {
        val p = prefs(context)
        val prefix = "w_${mod}_"
        val editor = p.edit()
        val hPrefix = "h_${mod}_"
        p.all.keys.filter { it.startsWith(prefix) || it.startsWith(hPrefix) }.forEach { editor.remove(it) }
        editor.apply()
        File(root(context), mod).deleteRecursively()
    }

    fun framesDir(context: Context, id: Int, mod: String = ModStore.activeId(context)): File =
        File(root(context), "$mod/$id")

    fun tempDir(context: Context, id: Int, mod: String = ModStore.activeId(context)): File =
        File(root(context), "$mod/${id}_tmp")
}
