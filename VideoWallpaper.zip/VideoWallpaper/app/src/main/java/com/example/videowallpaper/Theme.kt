package com.example.videowallpaper

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * الغرض: هوية التطبيق البصرية: أخضر داكن متدرج، بطاقات هادئة، ولمسات خضراء.
 * التصميم داكن دائماً (بغض النظر عن ثيم النظام) ليطابق التصميم المعتمد.
 */
private val BgEdge = Color(0xFF030D08)
private val BgGlow = Color(0xFF0C2D1E)

private val AppColorScheme = darkColorScheme(
    primary = Color(0xFF4CC58A),
    onPrimary = Color(0xFF00210F),
    primaryContainer = Color(0xFF0A3020),
    onPrimaryContainer = Color(0xFFE8EDE9),
    secondary = Color(0xFF9DB56A),
    onSecondary = Color(0xFF1B2300),
    secondaryContainer = Color(0xFF1B2A22),
    onSecondaryContainer = Color(0xFFE8EDE9),
    tertiary = Color(0xFF7FD6C2),
    // شفاف ليظهر التدرج الأخضر خلف Scaffold
    background = Color.Transparent,
    onBackground = Color(0xFFE8EDE9),
    surface = Color(0xFF0B140F),
    onSurface = Color(0xFFE8EDE9),
    surfaceVariant = Color(0xFF151C18),
    onSurfaceVariant = Color(0xFFA9B5AE),
    surfaceContainerHighest = Color(0xFF151C18),
    surfaceContainerHigh = Color(0xFF101A14),
    surfaceContainer = Color(0xFF0E1712),
    outline = Color(0xFF1F7A4D),
    outlineVariant = Color(0xFF2A3A31),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

/**
 * @param withBackground اجعله false حين تكون الشاشة شفافة فوق تطبيق آخر (قائمة الـ Tile).
 */
@Composable
internal fun AppTheme(withBackground: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AppColorScheme, shapes = AppShapes) {
        if (withBackground) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind {
                        drawRect(color = BgEdge)
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(BgGlow, BgEdge),
                                center = Offset(size.width * 0.5f, size.height * 0.72f),
                                radius = size.maxDimension * 0.75f
                            )
                        )
                    }
            ) {
                content()
            }
        } else {
            content()
        }
    }
}

/** شريط علوي شفاف يتناسب مع الخلفية المتدرجة. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun AppTopBar(
    title: @Composable () -> Unit,
    navigationIcon: @Composable () -> Unit = {}
) {
    TopAppBar(
        title = title,
        navigationIcon = navigationIcon,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.Transparent,
            scrolledContainerColor = Color.Transparent
        )
    )
}

/** علامة "+" الدائرية المستخدمة كمؤشر في الإرشادات. */
@Composable
internal fun PlusBadge(size: Dp = 28.dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Default.Add,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(size * 0.65f)
        )
    }
}
