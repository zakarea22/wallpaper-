package com.example.videowallpaper

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.Locale

/**
 * الغرض: شاشة إعداد الويدجت (تُفتح بالضغط على الإطار الفارغ أو من «تعديل»):
 * اختيار التطبيق الهدف (ويدجت الاختصار)، اختيار صورة/GIF/فيديو، الجودة، والاسم الاختياري.
 */
class WidgetConfigActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val widgetId = intent?.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val providerName = AppWidgetManager.getInstance(this)
            .getAppWidgetInfo(widgetId)?.provider?.className.orEmpty()
        val isShortcut = providerName.endsWith("ShortcutWidgetProvider")

        setContent {
            AppTheme {
                ConfigScreen(widgetId = widgetId, isShortcut = isShortcut, onFinish = { finish() })
            }
        }
    }
}

private data class AppItem(val pkg: String, val label: String, val icon: ImageBitmap?)

private const val MAX_LABEL_LENGTH = 30

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConfigScreen(widgetId: Int, isShortcut: Boolean, onFinish: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val existing = remember { WidgetStore.get(context, widgetId) }

    var mediaUri by remember { mutableStateOf(existing?.sourceUri?.let { Uri.parse(it) }) }
    var mediaChanged by remember { mutableStateOf(false) }
    var quality by remember { mutableIntStateOf(existing?.quality ?: 1) }
    var appPackage by remember { mutableStateOf(existing?.appPackage) }
    var labelText by remember { mutableStateOf(existing?.label.orEmpty()) }
    var showPicker by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }

    BackHandler(enabled = showPicker) { showPicker = false }

    val mediaLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            mediaUri = uri
            mediaChanged = true
            failed = false
        }
    }

    val mime = remember(mediaUri) {
        mediaUri?.let { context.contentResolver.getType(it) }.orEmpty().lowercase(Locale.US)
    }
    val isAnimated = mime.startsWith("video/") || mime == "image/gif"

    val fileName by produceState(initialValue = "", mediaUri) {
        val uri = mediaUri
        value = if (uri == null) "" else withContext(Dispatchers.IO) {
            runCatching { DocumentFile.fromSingleUri(context, uri)?.name }.getOrNull().orEmpty()
        }
    }
    val thumb by produceState<ImageBitmap?>(initialValue = null, mediaUri) {
        val uri = mediaUri
        value = if (uri == null) null else withContext(Dispatchers.IO) {
            FrameExtractor.thumbnail(context, uri, 320)?.asImageBitmap()
        }
    }

    val canSave = mediaUri != null && (!isShortcut || appPackage != null) && !busy

    fun save() {
        val uri = mediaUri ?: return
        busy = true
        failed = false
        progress = 0
        scope.launch {
            val ok = withContext(Dispatchers.Default) {
                try {
                    var kind = existing?.kind ?: "image"
                    var frames = existing?.frameCount ?: 1
                    var alpha = existing?.hasAlpha ?: false

                    val framesDir = WidgetStore.framesDir(context, widgetId)
                    val needExtract = mediaChanged ||
                        existing == null ||
                        existing.quality != quality ||
                        !framesDir.exists()

                    if (needExtract) {
                        val tmp = WidgetStore.tempDir(context, widgetId)
                        val r = FrameExtractor.extract(context, uri, tmp, quality) { p -> progress = p }
                        framesDir.deleteRecursively()
                        if (!tmp.renameTo(framesDir)) throw IOException("rename failed")
                        kind = r.kind
                        frames = r.frameCount
                        alpha = r.hasAlpha
                    }

                    WidgetStore.save(
                        context,
                        WidgetConfig(
                            widgetId = widgetId,
                            sourceUri = uri.toString(),
                            kind = kind,
                            frameCount = frames,
                            hasAlpha = alpha,
                            quality = quality,
                            appPackage = if (isShortcut) appPackage else null,
                            label = if (isShortcut) labelText.trim().takeIf { it.isNotEmpty() } else null
                        )
                    )
                    WidgetRenderer.update(context, widgetId)
                    true
                } catch (e: Exception) {
                    Log.e("WidgetConfig", "save failed", e)
                    false
                }
            }
            busy = false
            if (ok) onFinish() else failed = true
        }
    }

    if (showPicker) {
        AppPickerScreen(
            onPick = {
                appPackage = it
                showPicker = false
            },
            onBack = { showPicker = false }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        stringResource(
                            if (isShortcut) R.string.config_title_shortcut else R.string.config_title_media
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onFinish) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ---- التطبيق الهدف (ويدجت الاختصار فقط)
            if (isShortcut) {
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val info = remember(appPackage) { appPackage?.let { loadAppInfo(context, it) } }
                        val icon = info?.icon
                        if (icon != null) {
                            Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(40.dp))
                            Spacer(Modifier.width(12.dp))
                        }
                        Text(
                            text = info?.label ?: stringResource(R.string.config_app_none),
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Button(onClick = { showPicker = true }, enabled = !busy) {
                            Text(stringResource(R.string.config_choose_app))
                        }
                    }
                }
            }

            // ---- الوسائط
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        text = stringResource(R.string.config_choose_media),
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val t = thumb
                        if (t != null) {
                            Image(
                                bitmap = t,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(Modifier.width(12.dp))
                        }
                        Text(
                            text = if (fileName.isNotEmpty()) fileName
                            else stringResource(R.string.config_media_none),
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Button(
                            onClick = { mediaLauncher.launch(arrayOf("image/*", "video/*")) },
                            enabled = !busy
                        ) {
                            Text(stringResource(R.string.config_pick))
                        }
                    }
                }
            }

            // ---- الجودة (للـ GIF والفيديو فقط)
            if (isAnimated) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            text = stringResource(R.string.config_quality),
                            style = MaterialTheme.typography.titleMedium
                        )
                        val options = listOf(
                            0 to R.string.config_q_sharp,
                            1 to R.string.config_q_balanced,
                            2 to R.string.config_q_smooth
                        )
                        options.forEach { (level, res) ->
                            val seconds = String.format(
                                Locale.getDefault(),
                                "%.1f",
                                FrameExtractor.QUALITY_MAX_FRAMES[level] *
                                    FrameExtractor.FRAME_INTERVAL_MS / 1000.0
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = !busy) { quality = level },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = quality == level,
                                    onClick = { quality = level },
                                    enabled = !busy
                                )
                                Text(
                                    text = stringResource(res, seconds),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                        Text(
                            text = stringResource(R.string.config_quality_note),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            // ---- الاسم (ويدجت الاختصار فقط)
            if (isShortcut) {
                OutlinedTextField(
                    value = labelText,
                    onValueChange = { if (it.length <= MAX_LABEL_LENGTH) labelText = it },
                    singleLine = true,
                    enabled = !busy,
                    label = { Text(stringResource(R.string.config_label)) },
                    supportingText = { Text(stringResource(R.string.config_label_hint)) },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (busy) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    Text(
                        text = stringResource(R.string.config_preparing, progress),
                        modifier = Modifier.padding(start = 12.dp)
                    )
                }
            }
            if (failed) {
                Text(
                    text = stringResource(R.string.config_error_media),
                    color = MaterialTheme.colorScheme.error
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onFinish, enabled = !busy) {
                    Text(stringResource(R.string.cancel))
                }
                Spacer(Modifier.width(8.dp))
                Button(onClick = { save() }, enabled = canSave) {
                    Text(stringResource(R.string.save))
                }
            }
        }
    }
}

// ====================================================================== اختيار التطبيق

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppPickerScreen(onPick: (String) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val apps by produceState<List<AppItem>?>(initialValue = null) {
        value = withContext(Dispatchers.Default) { loadApps(context) }
    }
    var query by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.config_choose_app)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                label = { Text(stringResource(R.string.config_search_app)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
            val list = apps
            if (list == null) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator()
                }
            } else {
                val filtered = list.filter { it.label.contains(query.trim(), ignoreCase = true) }
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(filtered, key = { it.pkg }) { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(app.pkg) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val icon = app.icon
                            if (icon != null) {
                                Image(
                                    bitmap = icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(40.dp)
                                )
                            } else {
                                Spacer(Modifier.size(40.dp))
                            }
                            Text(
                                text = app.label,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.padding(start = 16.dp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun loadApps(context: Context): List<AppItem> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            val icon = try {
                ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
            } catch (e: Exception) {
                null
            }
            AppItem(ri.activityInfo.packageName, ri.loadLabel(pm).toString(), icon)
        }
        .sortedBy { it.label.lowercase() }
}

private fun loadAppInfo(context: Context, pkg: String): AppItem? = try {
    val pm = context.packageManager
    val info = pm.getApplicationInfo(pkg, 0)
    AppItem(
        pkg,
        pm.getApplicationLabel(info).toString(),
        pm.getApplicationIcon(info).toBitmap(96, 96).asImageBitmap()
    )
} catch (e: Exception) {
    null
}
