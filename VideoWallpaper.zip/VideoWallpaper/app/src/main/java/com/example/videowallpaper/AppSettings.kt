package com.example.videowallpaper

import android.content.Context
import android.content.SharedPreferences

/**
 * الغرض: إعدادات التطبيق العامة (تنطبق على كل الأوضاع).
 * تُقرأ من الخدمة والويدجتات مباشرة من SharedPreferences، فلا حاجة لحالة في الذاكرة.
 */
object AppSettings {

    const val PREFS = "app_settings"

    const val KEY_SAVER_ENABLED = "saver_enabled"
    const val KEY_SAVER_THRESHOLD = "saver_threshold"
    const val KEY_SPEED = "speed"
    const val KEY_FIT = "scale_fit"
    const val KEY_SHAPE = "shape"
    const val KEY_BORDER = "border"
    const val KEY_REFRESH_TICK = "refresh_tick"
    const val KEY_SCHED_ENABLED = "sched_enabled"
    const val KEY_SCHED_DAY_MOD = "sched_day_mod"
    const val KEY_SCHED_NIGHT_MOD = "sched_night_mod"
    const val KEY_SCHED_DAY_HOUR = "sched_day_hour"
    const val KEY_SCHED_NIGHT_HOUR = "sched_night_hour"

    /** نسب البطارية المتاحة لإيقاف الحركة. */
    val SAVER_THRESHOLDS = listOf(10, 15, 20, 30)

    /** سرعات التشغيل المتاحة. */
    val SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)

    /**
     * شكل زوايا الويدجت كنسبة من أصغر ضلع: 0 = بلا استدارة.
     * القيم بالترتيب: بلا، خفيفة، متوسطة، كبيرة، دائرة.
     */
    val SHAPE_FRACTIONS = listOf(0f, 0.08f, 0.16f, 0.28f, 0.5f)

    /** ألوان الإطار: 0 = بلا، 1 = أبيض، 2 = أخضر التطبيق. */
    val BORDER_COLORS = listOf(0, 0xFFFFFFFF.toInt(), 0xFF4CC58A.toInt())

    fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun saverEnabled(context: Context) = prefs(context).getBoolean(KEY_SAVER_ENABLED, true)
    fun saverThreshold(context: Context) = prefs(context).getInt(KEY_SAVER_THRESHOLD, 15)
    fun speed(context: Context) = prefs(context).getFloat(KEY_SPEED, 1f)
    fun fit(context: Context) = prefs(context).getBoolean(KEY_FIT, false)
    fun shapeIndex(context: Context) =
        prefs(context).getInt(KEY_SHAPE, 0).coerceIn(0, SHAPE_FRACTIONS.lastIndex)
    fun borderIndex(context: Context) =
        prefs(context).getInt(KEY_BORDER, 0).coerceIn(0, BORDER_COLORS.lastIndex)

    fun setSaverEnabled(context: Context, v: Boolean) =
        prefs(context).edit().putBoolean(KEY_SAVER_ENABLED, v).apply()
    fun setSaverThreshold(context: Context, v: Int) =
        prefs(context).edit().putInt(KEY_SAVER_THRESHOLD, v).apply()
    fun setSpeed(context: Context, v: Float) =
        prefs(context).edit().putFloat(KEY_SPEED, v).apply()
    fun setFit(context: Context, v: Boolean) =
        prefs(context).edit().putBoolean(KEY_FIT, v).apply()
    fun setShapeIndex(context: Context, v: Int) =
        prefs(context).edit().putInt(KEY_SHAPE, v).apply()
    fun setBorderIndex(context: Context, v: Int) =
        prefs(context).edit().putInt(KEY_BORDER, v).apply()

    // ---- التبديل التلقائي بالساعة
    fun schedEnabled(context: Context) = prefs(context).getBoolean(KEY_SCHED_ENABLED, false)
    fun schedDayMod(context: Context): String? = prefs(context).getString(KEY_SCHED_DAY_MOD, null)
    fun schedNightMod(context: Context): String? = prefs(context).getString(KEY_SCHED_NIGHT_MOD, null)
    fun schedDayHour(context: Context) = prefs(context).getInt(KEY_SCHED_DAY_HOUR, 7).coerceIn(0, 23)
    fun schedNightHour(context: Context) = prefs(context).getInt(KEY_SCHED_NIGHT_HOUR, 19).coerceIn(0, 23)

    fun setSchedEnabled(context: Context, v: Boolean) =
        prefs(context).edit().putBoolean(KEY_SCHED_ENABLED, v).apply()
    fun setSchedDayMod(context: Context, v: String) =
        prefs(context).edit().putString(KEY_SCHED_DAY_MOD, v).apply()
    fun setSchedNightMod(context: Context, v: String) =
        prefs(context).edit().putString(KEY_SCHED_NIGHT_MOD, v).apply()
    fun setSchedDayHour(context: Context, v: Int) =
        prefs(context).edit().putInt(KEY_SCHED_DAY_HOUR, v).apply()
    fun setSchedNightHour(context: Context, v: Int) =
        prefs(context).edit().putInt(KEY_SCHED_NIGHT_HOUR, v).apply()

    /** تغيير هذه القيمة يطلب من الخلفية الحية إعادة تشغيل الفيديو (مثلاً بعد الإقلاع). */
    fun bumpRefreshTick(context: Context) =
        prefs(context).edit().putLong(KEY_REFRESH_TICK, System.nanoTime()).apply()
}
