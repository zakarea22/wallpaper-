package com.example.videowallpaper

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * الغرض: صورة الوضع المصغرة (تُقرأ من القرص عند الحاجة فقط، حجمها 256px) أو أيقونة بديلة.
 * مشتركة بين شاشة الأوضاع وقائمة الـ Tile.
 */
@Composable
internal fun ModThumb(mod: Mod, size: Dp, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(null, mod.id, mod.thumbStamp) {
        value = withContext(Dispatchers.IO) { ModStore.loadThumb(context, mod)?.asImageBitmap() }
    }
    val shape = RoundedCornerShape(12.dp)
    val bmp = bitmap
    if (bmp != null) {
        Image(
            bitmap = bmp,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier
                .size(size)
                .clip(shape)
        )
    } else {
        Box(
            modifier = modifier
                .size(size)
                .clip(shape)
                .background(MaterialTheme.colorScheme.secondaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(size / 2))
        }
    }
}

/**
 * الغرض: شاشة إدارة الأوضاع: إنشاء، تعديل (الاسم + الصورة المصغرة)، حذف بتأكيد، وتفعيل وضع.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ModsScreen(resumeTick: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val mods = remember(resumeTick, tick) { ModStore.list(context) }
    val activeId = remember(resumeTick, tick) { ModStore.activeId(context) }

    var creating by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Mod?>(null) }
    var deleting by remember { mutableStateOf<Mod?>(null) }

    Scaffold(
        topBar = {
            AppTopBar(
                title = { Text(stringResource(R.string.mods_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { creating = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.mods_new))
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (mods.size < 2) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PlusBadge(size = 32.dp)
                            Text(
                                text = stringResource(R.string.mods_need_two),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(start = 12.dp)
                            )
                        }
                    }
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = stringResource(R.string.mods_howto, stringResource(R.string.tile_label)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = stringResource(R.string.mods_note_editing),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = stringResource(R.string.mods_note_wallpaper),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            items(mods, key = { it.id }) { mod ->
                val isActive = mod.id == activeId
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            ModStore.apply(context, mod.id)
                            tick++
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isActive) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    border = if (isActive) BorderStroke(1.dp, MaterialTheme.colorScheme.outline) else null
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ModThumb(mod = mod, size = 56.dp)
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 12.dp)
                        ) {
                            Text(text = mod.name, style = MaterialTheme.typography.titleMedium)
                            if (isActive) {
                                Text(
                                    text = stringResource(R.string.mods_active),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        IconButton(onClick = { editing = mod }) {
                            Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.mods_edit))
                        }
                        IconButton(onClick = { deleting = mod }) {
                            Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.mods_delete))
                        }
                    }
                }
            }
        }
    }

    if (creating) {
        ModEditDialog(
            title = stringResource(R.string.mods_new_title),
            initialName = "",
            showClone = true,
            onConfirm = { name, thumb, clone ->
                creating = false
                scope.launch(Dispatchers.IO) {
                    ModStore.create(context, name, clone, thumb)
                    withContext(Dispatchers.Main) { tick++ }
                }
            },
            onDismiss = { creating = false }
        )
    }

    editing?.let { mod ->
        ModEditDialog(
            title = stringResource(R.string.mods_edit_title),
            initialName = mod.name,
            showClone = false,
            onConfirm = { name, thumb, _ ->
                editing = null
                scope.launch(Dispatchers.IO) {
                    ModStore.rename(context, mod.id, name)
                    if (thumb != null) ModStore.setThumb(context, mod.id, thumb)
                    withContext(Dispatchers.Main) { tick++ }
                }
            },
            onDismiss = { editing = null }
        )
    }

    deleting?.let { mod ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(stringResource(R.string.mods_delete_title)) },
            text = { Text(stringResource(R.string.mods_delete_message)) },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch(Dispatchers.IO) {
                        val ok = ModStore.delete(context, mod.id)
                        withContext(Dispatchers.Main) {
                            if (!ok) {
                                Toast.makeText(context, R.string.mods_delete_last, Toast.LENGTH_SHORT).show()
                            }
                            tick++
                        }
                    }
                }) {
                    Text(stringResource(R.string.delete_confirm_button))
                }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

@Composable
private fun ModEditDialog(
    title: String,
    initialName: String,
    showClone: Boolean,
    onConfirm: (name: String, thumb: Uri?, clone: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(initialName) }
    var thumbUri by remember { mutableStateOf<Uri?>(null) }
    var clone by remember { mutableStateOf(true) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) thumbUri = uri
    }
    val preview by produceState<ImageBitmap?>(null, thumbUri) {
        val uri = thumbUri
        value = if (uri == null) null else withContext(Dispatchers.IO) {
            FrameExtractor.thumbnail(context, uri, 160)?.asImageBitmap()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= ModStore.MAX_NAME_LENGTH) name = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.mods_name_label)) },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val shown = preview
                    if (shown != null) {
                        Image(
                            bitmap = shown,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = if (shown != null) 12.dp else 0.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.mods_thumb_hint),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(onClick = { picker.launch(arrayOf("image/*", "video/*")) }) {
                        Text(stringResource(R.string.mods_thumb_pick))
                    }
                }
                if (showClone) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { clone = !clone },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = clone, onCheckedChange = { clone = it })
                        Text(
                            text = stringResource(R.string.mods_clone),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(name, thumbUri, clone) }) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}
