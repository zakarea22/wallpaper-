package com.example.videowallpaper

import android.annotation.TargetApi
import android.app.WallpaperColors
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.media.MediaPlayer
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder
import java.io.IOException

/**
 * الغرض: خدمة خلفية حية تشغّل فيديو محلياً (MediaPlayer) بشكل متكرر وصامت،
 * مع إيقاف مؤقت عند اختفاء الخلفية لتوفير البطارية.
 * ملاحظة: الـ Surface الخاص بالـ Engine هو سطح الرسم المخصص للخلفية (بديل SurfaceView).
 */
class VideoWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = VideoEngine()

    inner class VideoEngine : Engine() {

        private var player: MediaPlayer? = null
        private var surfaceHolder: SurfaceHolder? = null
        private var visible = false
        private var prepared = false
        private var playingUri: android.net.Uri? = null
        private var wallpaperColors: Any? = null // WallpaperColors (API 27+)
        private var colorsUri: android.net.Uri? = null
        private var destroyed = false
        private val mainHandler = Handler(Looper.getMainLooper())
        private lateinit var prefs: WallpaperPrefs

        // نحتفظ بمرجع قوي للمستمع كي لا يُجمَّع بواسطة الـ GC
        private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == WallpaperPrefs.KEY_ACTIVE) {
                // نفس الفيديو يعمل أصلاً (مثلاً وضعان بنفس الخلفية): لا نعيد التشغيل فلا يحدث وميض
                val wanted = prefs.getActiveVideo()
                if (wanted != null && wanted == playingUri && player != null) return@OnSharedPreferenceChangeListener
                surfaceHolder?.let { holder ->
                    releasePlayer()
                    startPlayer(holder)
                }
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(false)
            prefs = WallpaperPrefs(applicationContext)
            prefs.registerListener(prefsListener)
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            surfaceHolder = holder
            startPlayer(holder)
        }

        override fun onSurfaceChanged(
            holder: SurfaceHolder, format: Int, width: Int, height: Int
        ) {
            super.onSurfaceChanged(holder, format, width, height)
            // الـ CENTER_CROP يتولاه MediaPlayer عبر scaling mode؛ لا حاجة لعمل إضافي هنا.
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            this.visible = visible
            val p = player ?: return
            if (!prepared) return // سيبدأ تلقائياً في onPrepared إن كان ظاهراً
            try {
                if (visible) {
                    if (!p.isPlaying) p.start()
                } else {
                    if (p.isPlaying) p.pause()
                }
            } catch (e: IllegalStateException) {
                Log.w(TAG, "visibility state error", e)
                releasePlayer()
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            releasePlayer()
            surfaceHolder = null
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            destroyed = true
            if (::prefs.isInitialized) prefs.unregisterListener(prefsListener)
            releasePlayer()
            surfaceHolder = null
            super.onDestroy()
        }

        private fun startPlayer(holder: SurfaceHolder) {
            val uri = prefs.getActiveVideo() ?: return
            playingUri = uri
            refreshColors(uri)
            val mp = MediaPlayer()
            try {
                mp.setSurface(holder.surface)
                mp.setDataSource(applicationContext, uri)
                mp.isLooping = true
                mp.setVolume(0f, 0f)

                mp.setOnPreparedListener { p ->
                    if (p !== player) return@setOnPreparedListener
                    prepared = true
                    try {
                        p.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING)
                        if (visible) {
                            p.start()
                        } else {
                            // الخلفية غير ظاهرة الآن (مثلاً نسخة يستخدمها اللانشر للتمويه): نرسم الإطار الأول
                            // فوراً كي لا يبقى على السطح آخر إطار من الفيديو القديم (سبب تداخل ألوان وضعين).
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                p.seekTo(0L, MediaPlayer.SEEK_CLOSEST)
                            } else {
                                p.seekTo(0)
                            }
                        }
                    } catch (e: IllegalStateException) {
                        Log.w(TAG, "onPrepared error", e)
                        releasePlayer()
                    }
                }
                mp.setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaPlayer error what=$what extra=$extra")
                    releasePlayer()
                    true // تم التعامل مع الخطأ؛ لا crash
                }

                player = mp
                mp.prepareAsync()
            } catch (e: IOException) {
                Log.e(TAG, "IO error (deleted file / bad URI?)", e)
                safeRelease(mp)
            } catch (e: IllegalStateException) {
                Log.e(TAG, "Illegal state", e)
                safeRelease(mp)
            } catch (e: SecurityException) {
                Log.e(TAG, "URI permission lost", e)
                safeRelease(mp)
            } catch (e: IllegalArgumentException) {
                Log.e(TAG, "Invalid URI", e)
                safeRelease(mp)
            }
        }

        /** ألوان الخلفية التي يقرأها النظام/اللانشر (للتمويه والتلوين). نحدّثها عند تغيّر الفيديو. */
        @TargetApi(Build.VERSION_CODES.O_MR1)
        override fun onComputeColors(): WallpaperColors? = wallpaperColors as? WallpaperColors

        private fun refreshColors(uri: android.net.Uri) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O_MR1 || colorsUri == uri) return
            colorsUri = uri
            val app = applicationContext
            Thread {
                try {
                    val bmp = FrameExtractor.thumbnail(app, uri, 96) ?: return@Thread
                    val colors = WallpaperColors.fromBitmap(bmp)
                    bmp.recycle()
                    mainHandler.post {
                        if (!destroyed && colorsUri == uri) {
                            wallpaperColors = colors
                            notifyColorsChanged()
                        }
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "colors failed", t)
                }
            }.start()
        }

        private fun releasePlayer() {
            val p = player
            player = null
            prepared = false
            playingUri = null
            if (p != null) safeRelease(p)
        }

        private fun safeRelease(mp: MediaPlayer) {
            try {
                mp.setOnPreparedListener(null)
                mp.setOnErrorListener(null)
                mp.reset()
            } catch (_: Exception) {
            }
            try {
                mp.release()
            } catch (_: Exception) {
            }
            if (player === mp) player = null
        }
    }

    private companion object {
        const val TAG = "VideoWallpaper"
    }
}
