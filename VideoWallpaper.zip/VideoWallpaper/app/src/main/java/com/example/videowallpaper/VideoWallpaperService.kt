package com.example.videowallpaper

import android.annotation.TargetApi
import android.app.WallpaperColors
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer

/**
 * الغرض: خدمة خلفية حية تشغّل فيديو محلياً بشكل متكرر.
 *
 * المحرّك: ExoPlayer (Media3) مع **تعطيل مسار الصوت بالكامل**: لا يُفكّ الصوت ولا يُرسَل لأي مخرج،
 * فلا يلتقطه مسجّل الشاشة ولا يستهلك طاقة بلا فائدة. (MediaPlayer كان يفكّ الصوت ويكتمه فقط.)
 *
 * توفير الطاقة:
 *  - إيقاف مؤقت عند اختفاء الخلفية.
 *  - إيقاف الحركة (تبقى صورة ثابتة) عند تفعيل توفير الطاقة في النظام أو انخفاض البطارية
 *    تحت النسبة المختارة دون شحن (حسب الإعدادات).
 * التحكم: سرعة التشغيل وطريقة الملء (قص أو احتواء) من الإعدادات.
 *
 * عند تغيّر الفيديو (تبديل وضع) نعيد استخدام نفس المشغّل ونحمّل المصدر الجديد، فلا يُفصل السطح ويُعاد وصله.
 */
@OptIn(UnstableApi::class)
class VideoWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = VideoEngine()

    inner class VideoEngine : Engine() {

        private var player: ExoPlayer? = null
        private var playerListener: Player.Listener? = null
        private var surfaceHolder: SurfaceHolder? = null
        private var visible = false
        private var prepared = false
        private var playingUri: Uri? = null
        private var wallpaperColors: Any? = null // WallpaperColors (API 27+)
        private var colorsUri: Uri? = null
        private var destroyed = false
        private val mainHandler = Handler(Looper.getMainLooper())
        private val tag = "Engine#" + Integer.toHexString(System.identityHashCode(this))
        private lateinit var prefs: WallpaperPrefs

        // حالة توفير الطاقة
        private var saving = false
        private var batteryPct = 100
        private var plugged = false
        private var powerSave = false
        private var receiverRegistered = false

        // إعادة المحاولة عند فشل التحميل (مثلاً مباشرة بعد الإقلاع قبل جاهزية التخزين)
        private var retryCount = 0
        private val retryRunnable = Runnable {
            val holder = surfaceHolder
            if (!destroyed && holder != null && player == null) startPlayer(holder)
        }

        private fun log(msg: String) = AppLog.d(applicationContext, tag, msg)

        // نحتفظ بمراجع قوية للمستمعات كي لا تُجمَّع بواسطة الـ GC
        private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == WallpaperPrefs.KEY_ACTIVE) {
                val wanted = prefs.getActiveVideo()
                log("active changed -> $wanted (playing=$playingUri, surface=${surfaceHolder != null}, visible=$visible)")
                // نفس الفيديو يعمل أصلاً (مثلاً وضعان بنفس الخلفية): لا نعيد التشغيل فلا يحدث وميض
                if (wanted != null && wanted == playingUri && player != null) {
                    return@OnSharedPreferenceChangeListener
                }
                val holder = surfaceHolder ?: return@OnSharedPreferenceChangeListener
                val p = player
                if (p != null && wanted != null) {
                    loadSource(p, wanted) // نعيد استخدام المشغّل
                } else {
                    releasePlayer()
                    startPlayer(holder)
                }
            }
        }

        private val settingsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            when (key) {
                AppSettings.KEY_SPEED -> applySpeed()
                AppSettings.KEY_FIT -> applyScaleMode()
                AppSettings.KEY_REFRESH_TICK -> restartPlayer()
                AppSettings.KEY_SAVER_ENABLED, AppSettings.KEY_SAVER_THRESHOLD -> evaluateSaving()
            }
        }

        private val batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    Intent.ACTION_BATTERY_CHANGED -> readBattery(intent)
                    PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> readPowerSave()
                }
                evaluateSaving()
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(false)
            log("onCreate preview=$isPreview")
            prefs = WallpaperPrefs(applicationContext)
            prefs.registerListener(prefsListener)
            AppSettings.prefs(applicationContext).registerOnSharedPreferenceChangeListener(settingsListener)
            registerBatteryReceiver()
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            surfaceHolder = holder
            log("surfaceCreated")
            startPlayer(holder)
        }

        override fun onSurfaceChanged(
            holder: SurfaceHolder, format: Int, width: Int, height: Int
        ) {
            super.onSurfaceChanged(holder, format, width, height)
            // الملء يتولاه المشغّل عبر videoScalingMode؛ لا حاجة لعمل إضافي هنا.
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            this.visible = visible
            log("visible=$visible prepared=$prepared saving=$saving")
            applyPlayback()
            // إن فشل التحميل سابقاً ولا يوجد مشغّل، نحاول من جديد عند عودة الظهور
            if (visible && player == null) surfaceHolder?.let { startPlayer(it) }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            log("surfaceDestroyed")
            mainHandler.removeCallbacks(retryRunnable)
            releasePlayer()
            surfaceHolder = null
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            destroyed = true
            log("onDestroy")
            mainHandler.removeCallbacks(retryRunnable)
            if (::prefs.isInitialized) prefs.unregisterListener(prefsListener)
            AppSettings.prefs(applicationContext).unregisterOnSharedPreferenceChangeListener(settingsListener)
            unregisterBatteryReceiver()
            releasePlayer()
            surfaceHolder = null
            super.onDestroy()
        }

        // ------------------------------------------------------------ توفير الطاقة

        private fun registerBatteryReceiver() {
            try {
                val filter = IntentFilter().apply {
                    addAction(Intent.ACTION_BATTERY_CHANGED)
                    addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
                }
                val sticky = ContextCompat.registerReceiver(
                    applicationContext, batteryReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
                )
                receiverRegistered = true
                sticky?.let { readBattery(it) }
                readPowerSave()
                evaluateSaving()
            } catch (t: Throwable) {
                Log.w(TAG, "battery receiver failed", t)
            }
        }

        private fun unregisterBatteryReceiver() {
            if (!receiverRegistered) return
            try {
                applicationContext.unregisterReceiver(batteryReceiver)
            } catch (_: Exception) {
            }
            receiverRegistered = false
        }

        private fun readBattery(intent: Intent) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) batteryPct = level * 100 / scale
            plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        }

        private fun readPowerSave() {
            val pm = applicationContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
            powerSave = pm?.isPowerSaveMode ?: false
        }

        /** يحدد هل نوقف الحركة الآن، ويطبّق التغيير إن تغيّرت الحالة. */
        private fun evaluateSaving() {
            val app = applicationContext
            val now = !isPreview &&
                AppSettings.saverEnabled(app) &&
                (powerSave || (batteryPct <= AppSettings.saverThreshold(app) && !plugged))
            if (now != saving) {
                saving = now
                log("saving=$saving (battery=$batteryPct plugged=$plugged powerSave=$powerSave)")
                applyPlayback()
            }
        }

        /** يشغّل أو يوقف المشغّل حسب الظهور وحالة توفير الطاقة (يعمل حتى قبل اكتمال التحميل). */
        private fun applyPlayback() {
            val p = player ?: return
            try {
                p.playWhenReady = visible && !saving
            } catch (e: Exception) {
                Log.w(TAG, "playback state error", e)
                releasePlayer()
                scheduleRetry()
            }
        }

        // ------------------------------------------------------------ التشغيل

        private fun applySpeed() {
            val p = player ?: return
            try {
                p.playbackParameters = PlaybackParameters(AppSettings.speed(applicationContext))
            } catch (e: Exception) {
                Log.w(TAG, "speed failed", e)
            }
        }

        private fun applyScaleMode() {
            val p = player ?: return
            try {
                p.videoScalingMode = scalingMode()
            } catch (e: Exception) {
                Log.w(TAG, "scale mode failed", e)
            }
        }

        private fun scalingMode() =
            if (AppSettings.fit(applicationContext)) C.VIDEO_SCALING_MODE_SCALE_TO_FIT
            else C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING

        /** يحمّل مصدراً جديداً في مشغّل موجود (بدون فصل السطح). */
        private fun loadSource(p: ExoPlayer, uri: Uri) {
            playingUri = uri
            prepared = false
            log("loadSource $uri")
            refreshColors(uri)
            try {
                p.setMediaItem(MediaItem.fromUri(uri))
                p.prepare()
                applyPlayback()
            } catch (e: Exception) {
                Log.e(TAG, "loadSource failed", e)
                releasePlayer()
                scheduleRetry()
            }
        }

        private fun startPlayer(holder: SurfaceHolder) {
            val uri = prefs.getActiveVideo() ?: return
            playingUri = uri
            prepared = false
            log("startPlayer $uri")
            refreshColors(uri)
            try {
                val p = ExoPlayer.Builder(applicationContext).build()
                // تعطيل مسار الصوت كلياً: لا فك تشفير ولا مخرج صوت ولا التقاط للتسجيل
                p.trackSelectionParameters = p.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
                    .build()
                p.volume = 0f
                p.repeatMode = Player.REPEAT_MODE_ONE
                p.videoScalingMode = scalingMode()
                p.playbackParameters = PlaybackParameters(AppSettings.speed(applicationContext))
                p.setVideoSurface(holder.surface)

                val listener = object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (p !== player) return
                        if (playbackState == Player.STATE_READY && !prepared) {
                            prepared = true
                            retryCount = 0
                            mainHandler.removeCallbacks(retryRunnable)
                            log("prepared visible=$visible saving=$saving")
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        if (p !== player) return
                        Log.e(TAG, "player error ${error.errorCodeName}", error)
                        log("PLAYER ERROR ${error.errorCodeName}")
                        releasePlayer()
                        scheduleRetry()
                    }
                }
                p.addListener(listener)
                playerListener = listener
                player = p

                p.setMediaItem(MediaItem.fromUri(uri))
                p.playWhenReady = visible && !saving
                p.prepare()
            } catch (e: Exception) {
                Log.e(TAG, "startPlayer failed", e)
                log("startPlayer EXCEPTION $e")
                releasePlayer()
                scheduleRetry()
            }
        }

        /** ألوان الخلفية التي يقرأها النظام/اللانشر (للتمويه والتلوين). نحدّثها عند تغيّر الفيديو. */
        @TargetApi(Build.VERSION_CODES.O_MR1)
        override fun onComputeColors(): WallpaperColors? = wallpaperColors as? WallpaperColors

        private fun refreshColors(uri: Uri) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O_MR1 || colorsUri == uri) return
            colorsUri = uri
            val app = applicationContext
            Thread {
                try {
                    val bmp = FrameExtractor.thumbnail(app, uri, 96) ?: return@Thread
                    val colors = WallpaperColors.fromBitmap(bmp)
                    bmp.recycle()
                    mainHandler.post {
                        if (!destroyed && colorsUri == uri) {
                            wallpaperColors = colors
                            notifyColorsChanged()
                        }
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "colors failed", t)
                }
            }.start()
        }

        /** يعيد تشغيل الفيديو من الصفر (بعد الإقلاع مثلاً). */
        private fun restartPlayer() {
            val holder = surfaceHolder ?: return
            log("restartPlayer")
            retryCount = 0
            releasePlayer()
            startPlayer(holder)
        }

        private fun scheduleRetry() {
            if (destroyed || retryCount >= RETRY_DELAYS.size) return
            val delay = RETRY_DELAYS[retryCount++]
            log("retry #$retryCount in ${delay}ms")
            mainHandler.removeCallbacks(retryRunnable)
            mainHandler.postDelayed(retryRunnable, delay)
        }

        private fun releasePlayer() {
            val p = player
            val l = playerListener
            player = null
            playerListener = null
            prepared = false
            playingUri = null
            if (p != null) {
                try {
                    if (l != null) p.removeListener(l)
                    p.release()
                } catch (_: Exception) {
                }
            }
        }
    }

    private companion object {
        const val TAG = "VideoWallpaper"
        val RETRY_DELAYS = longArrayOf(1500, 3000, 6000, 12000, 20000)
    }
}
