package com.example.videowallpaper

import android.annotation.TargetApi
import android.app.WallpaperColors
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder
import androidx.core.content.ContextCompat
import java.io.IOException

/**
 * الغرض: خدمة خلفية حية تشغّل فيديو محلياً (MediaPlayer) بشكل متكرر وصامت.
 *
 * توفير الطاقة:
 *  - إيقاف مؤقت عند اختفاء الخلفية.
 *  - إيقاف الحركة (تبقى صورة ثابتة) عند تفعيل توفير الطاقة في النظام أو انخفاض البطارية
 *    تحت النسبة المختارة دون شحن (حسب الإعدادات).
 * التحكم: سرعة التشغيل وطريقة الملء (قص أو احتواء) من الإعدادات.
 */
class VideoWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = VideoEngine()

    inner class VideoEngine : Engine() {

        private var player: MediaPlayer? = null
        private var surfaceHolder: SurfaceHolder? = null
        private var visible = false
        private var prepared = false
        private var playingUri: Uri? = null
        private var wallpaperColors: Any? = null // WallpaperColors (API 27+)
        private var colorsUri: Uri? = null
        private var destroyed = false
        private val mainHandler = Handler(Looper.getMainLooper())
        private val tag = "Engine#" + Integer.toHexString(System.identityHashCode(this))
        private lateinit var prefs: WallpaperPrefs

        // حالة توفير الطاقة
        private var saving = false
        private var batteryPct = 100
        private var plugged = false
        private var powerSave = false
        private var receiverRegistered = false

        // إعادة المحاولة عند فشل التحميل (مثلاً مباشرة بعد الإقلاع قبل جاهزية التخزين)
        private var retryCount = 0
        private val retryRunnable = Runnable {
            val holder = surfaceHolder
            if (!destroyed && holder != null && player == null) startPlayer(holder)
        }

        private fun log(msg: String) = AppLog.d(applicationContext, tag, msg)

        // نحتفظ بمراجع قوية للمستمعات كي لا تُجمَّع بواسطة الـ GC
        private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == WallpaperPrefs.KEY_ACTIVE) {
                // نفس الفيديو يعمل أصلاً (مثلاً وضعان بنفس الخلفية): لا نعيد التشغيل فلا يحدث وميض
                val wanted = prefs.getActiveVideo()
                log("active changed -> $wanted (playing=$playingUri, surface=${surfaceHolder != null}, visible=$visible)")
                if (wanted != null && wanted == playingUri && player != null) {
                    return@OnSharedPreferenceChangeListener
                }
                surfaceHolder?.let { holder ->
                    releasePlayer()
                    startPlayer(holder)
                }
            }
        }

        private val settingsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            when (key) {
                AppSettings.KEY_SPEED -> applySpeedLive()
                AppSettings.KEY_FIT -> applyScaleMode()
                AppSettings.KEY_REFRESH_TICK -> restartPlayer()
                AppSettings.KEY_SAVER_ENABLED, AppSettings.KEY_SAVER_THRESHOLD -> evaluateSaving()
            }
        }

        private val batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    Intent.ACTION_BATTERY_CHANGED -> readBattery(intent)
                    PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> readPowerSave()
                }
                evaluateSaving()
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(false)
            log("onCreate preview=$isPreview")
            prefs = WallpaperPrefs(applicationContext)
            prefs.registerListener(prefsListener)
            AppSettings.prefs(applicationContext).registerOnSharedPreferenceChangeListener(settingsListener)
            registerBatteryReceiver()
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            surfaceHolder = holder
            log("surfaceCreated")
            startPlayer(holder)
        }

        override fun onSurfaceChanged(
            holder: SurfaceHolder, format: Int, width: Int, height: Int
        ) {
            super.onSurfaceChanged(holder, format, width, height)
            // الملء يتولاه MediaPlayer عبر scaling mode؛ لا حاجة لعمل إضافي هنا.
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            this.visible = visible
            log("visible=$visible prepared=$prepared saving=$saving")
            applyPlayback() // إن لم يكن جاهزاً بعد سيبدأ في onPrepared
            // إن فشل التحميل سابقاً ولا يوجد مشغّل، نحاول من جديد عند عودة الظهور
            if (visible && player == null) surfaceHolder?.let { startPlayer(it) }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            log("surfaceDestroyed")
            mainHandler.removeCallbacks(retryRunnable)
            releasePlayer()
            surfaceHolder = null
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            destroyed = true
            log("onDestroy")
            mainHandler.removeCallbacks(retryRunnable)
            if (::prefs.isInitialized) prefs.unregisterListener(prefsListener)
            AppSettings.prefs(applicationContext).unregisterOnSharedPreferenceChangeListener(settingsListener)
            unregisterBatteryReceiver()
            releasePlayer()
            surfaceHolder = null
            super.onDestroy()
        }

        // ------------------------------------------------------------ توفير الطاقة

        private fun registerBatteryReceiver() {
            try {
                val filter = IntentFilter().apply {
                    addAction(Intent.ACTION_BATTERY_CHANGED)
                    addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
                }
                val sticky = ContextCompat.registerReceiver(
                    applicationContext, batteryReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
                )
                receiverRegistered = true
                sticky?.let { readBattery(it) }
                readPowerSave()
                evaluateSaving()
            } catch (t: Throwable) {
                Log.w(TAG, "battery receiver failed", t)
            }
        }

        private fun unregisterBatteryReceiver() {
            if (!receiverRegistered) return
            try {
                applicationContext.unregisterReceiver(batteryReceiver)
            } catch (_: Exception) {
            }
            receiverRegistered = false
        }

        private fun readBattery(intent: Intent) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) batteryPct = level * 100 / scale
            plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        }

        private fun readPowerSave() {
            val pm = applicationContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
            powerSave = pm?.isPowerSaveMode ?: false
        }

        /** يحدد هل نوقف الحركة الآن، ويطبّق التغيير إن تغيّرت الحالة. */
        private fun evaluateSaving() {
            val app = applicationContext
            val now = !isPreview &&
                AppSettings.saverEnabled(app) &&
                (powerSave || (batteryPct <= AppSettings.saverThreshold(app) && !plugged))
            if (now != saving) {
                saving = now
                log("saving=$saving (battery=$batteryPct plugged=$plugged powerSave=$powerSave)")
                applyPlayback()
            }
        }

        /** يشغّل أو يوقف المشغّل حسب الظهور وحالة توفير الطاقة. */
        private fun applyPlayback() {
            val p = player ?: return
            if (!prepared) return
            try {
                if (visible && !saving) {
                    if (!p.isPlaying) startPlayback(p)
                } else {
                    if (p.isPlaying) p.pause()
                }
            } catch (e: IllegalStateException) {
                Log.w(TAG, "playback state error", e)
                releasePlayer()
            }
        }

        // ------------------------------------------------------------ التشغيل

        private fun startPlayback(p: MediaPlayer) {
            try {
                p.playbackParams = PlaybackParams().setSpeed(AppSettings.speed(applicationContext))
            } catch (e: Exception) {
                Log.w(TAG, "speed not applied", e)
            }
            p.start()
        }

        private fun applySpeedLive() {
            val p = player ?: return
            if (!prepared) return
            try {
                // إن كان متوقفاً تُطبَّق السرعة عند البدء (setPlaybackParams قد يشغّل المتوقف)
                if (p.isPlaying) {
                    p.playbackParams = PlaybackParams().setSpeed(AppSettings.speed(applicationContext))
                }
            } catch (e: Exception) {
                Log.w(TAG, "live speed failed", e)
            }
        }

        private fun applyScaleMode() {
            val p = player ?: return
            if (!prepared) return
            try {
                p.setVideoScalingMode(scalingMode())
            } catch (e: IllegalStateException) {
                Log.w(TAG, "scale mode failed", e)
            }
        }

        private fun scalingMode() =
            if (AppSettings.fit(applicationContext)) MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT
            else MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING

        private fun startPlayer(holder: SurfaceHolder) {
            val uri = prefs.getActiveVideo() ?: return
            playingUri = uri
            log("startPlayer $uri")
            refreshColors(uri)
            val mp = MediaPlayer()
            try {
                mp.setSurface(holder.surface)
                mp.setDataSource(applicationContext, uri)
                mp.isLooping = true
                mp.setVolume(0f, 0f)

                mp.setOnPreparedListener { p ->
                    if (p !== player) return@setOnPreparedListener
                    prepared = true
                    retryCount = 0
                    mainHandler.removeCallbacks(retryRunnable)
                    log("prepared visible=$visible saving=$saving")
                    try {
                        p.setVideoScalingMode(scalingMode())
                        if (visible && !saving) {
                            startPlayback(p)
                        } else {
                            // غير ظاهرة أو في توفير الطاقة: نرسم الإطار الأول فوراً كي لا يبقى
                            // على السطح آخر إطار من الفيديو القديم.
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                p.seekTo(0L, MediaPlayer.SEEK_CLOSEST)
                            } else {
                                p.seekTo(0)
                            }
                        }
                    } catch (e: IllegalStateException) {
                        Log.w(TAG, "onPrepared error", e)
                        releasePlayer()
                        scheduleRetry()
                    }
                }
                mp.setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaPlayer error what=$what extra=$extra")
                    log("MediaPlayer ERROR what=$what extra=$extra")
                    releasePlayer()
                    scheduleRetry()
                    true // تم التعامل مع الخطأ؛ لا crash
                }

                player = mp
                mp.prepareAsync()
            } catch (e: IOException) {
                Log.e(TAG, "IO error (deleted file / bad URI?)", e)
                safeRelease(mp)
                scheduleRetry()
            } catch (e: IllegalStateException) {
                Log.e(TAG, "Illegal state", e)
                safeRelease(mp)
                scheduleRetry()
            } catch (e: SecurityException) {
                Log.e(TAG, "URI permission lost", e)
                safeRelease(mp)
                scheduleRetry()
            } catch (e: IllegalArgumentException) {
                Log.e(TAG, "Invalid URI", e)
                safeRelease(mp)
                scheduleRetry()
            }
        }

        /** ألوان الخلفية التي يقرأها النظام/اللانشر (للتمويه والتلوين). نحدّثها عند تغيّر الفيديو. */
        @TargetApi(Build.VERSION_CODES.O_MR1)
        override fun onComputeColors(): WallpaperColors? = wallpaperColors as? WallpaperColors

        private fun refreshColors(uri: Uri) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O_MR1 || colorsUri == uri) return
            colorsUri = uri
            val app = applicationContext
            Thread {
                try {
                    val bmp = FrameExtractor.thumbnail(app, uri, 96) ?: return@Thread
                    val colors = WallpaperColors.fromBitmap(bmp)
                    bmp.recycle()
                    mainHandler.post {
                        if (!destroyed && colorsUri == uri) {
                            wallpaperColors = colors
                            notifyColorsChanged()
                        }
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "colors failed", t)
                }
            }.start()
        }

        /** يعيد تشغيل الفيديو من الصفر (إعادة بعد الإقلاع مثلاً). */
        private fun restartPlayer() {
            val holder = surfaceHolder ?: return
            log("restartPlayer")
            retryCount = 0
            releasePlayer()
            startPlayer(holder)
        }

        private fun scheduleRetry() {
            if (destroyed || retryCount >= RETRY_DELAYS.size) return
            val delay = RETRY_DELAYS[retryCount++]
            log("retry #$retryCount in ${delay}ms")
            mainHandler.removeCallbacks(retryRunnable)
            mainHandler.postDelayed(retryRunnable, delay)
        }

        private fun releasePlayer() {
            val p = player
            player = null
            prepared = false
            playingUri = null
            if (p != null) safeRelease(p)
        }

        private fun safeRelease(mp: MediaPlayer) {
            try {
                mp.setOnPreparedListener(null)
                mp.setOnErrorListener(null)
                mp.reset()
            } catch (_: Exception) {
            }
            try {
                mp.release()
            } catch (_: Exception) {
            }
            if (player === mp) player = null
        }
    }

    private companion object {
        const val TAG = "VideoWallpaper"
        val RETRY_DELAYS = longArrayOf(1500, 3000, 6000, 12000, 20000)
    }
}
