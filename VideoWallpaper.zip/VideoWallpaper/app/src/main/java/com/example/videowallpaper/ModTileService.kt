package com.example.videowallpaper

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * الغرض: زر في الإعدادات السريعة.
 *  - ضغطة واحدة: ينتقل للوضع التالي (من الأعلى للأسفل ثم يعود للأول).
 *  - ضغطة مطولة: النظام يفتح ModPickerActivity (QS_TILE_PREFERENCES) بقائمة كل الأوضاع.
 *
 * onClick يكتب قيمة صغيرة فقط ويرسل إعادة رسم الويدجتات لخيط خلفي، فلا يتأخر شيء على خيط النظام.
 * الخدمة لا تحتفظ بأي حالة، فلا توجد تسريبات.
 */
class ModTileService : TileService() {

    override fun onStartListening() {
        refreshTile()
    }

    override fun onClick() {
        val next = ModStore.next(this)
        ModStore.apply(this, next.id)
        refreshTile()
    }

    private fun refreshTile() {
        val tile = qsTile ?: return
        tile.label = ModStore.active(this).name
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = getString(R.string.tile_subtitle)
        }
        tile.state = Tile.STATE_ACTIVE
        tile.updateTile()
    }
}
