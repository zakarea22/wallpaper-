package com.example.videowallpaper

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * الغرض: بناء RemoteViews لكل ويدجت وإرسالها للنظام.
 *
 * - بدون إعدادات: إطار فارغ شفاف، الضغط عليه يفتح شاشة الإعداد.
 * - مع إعدادات: ViewFlipper يقلّب الإطارات المحفوظة (الحركة)، مع اسم اختياري وفتح تطبيق عند الضغط.
 *
 * النظام يحدّ مجموع ذاكرة الصور في تحديث الويدجت (حوالي 6 × عرض الشاشة × ارتفاعها بايت)،
 * لذلك نصغّر الإطارات حسب حجم الويدجت وعددها، ونعيد المحاولة بميزانية أقل عند الفشل.
 */
object WidgetRenderer {

    private const val TAG = "WidgetRenderer"
    private const val MIN_RENDER_WIDTH = 120

    fun update(context: Context, widgetId: Int) {
        val app = context.applicationContext
        update(app, AppWidgetManager.getInstance(app), widgetId)
    }

    fun update(context: Context, manager: AppWidgetManager, widgetId: Int) {
        val app = context.applicationContext
        val mod = ModStore.activeId(app)
        if (WidgetStore.isHidden(app, widgetId, mod)) {
            // مخفي في هذا الوضع: إطار شفاف بلا صور ولا مستمعات (أخف ما يمكن)
            pushSafely(manager, widgetId, RemoteViews(app.packageName, R.layout.widget_hidden))
            return
        }
        val cfg = WidgetStore.get(app, widgetId, mod)
        if (cfg == null) {
            pushSafely(manager, widgetId, emptyViews(app, widgetId))
            return
        }

        var factor = 0.55
        repeat(3) { attempt ->
            val bitmaps = mutableListOf<Bitmap>()
            try {
                val views = buildMediaViews(app, manager, cfg, mod, factor, bitmaps)
                manager.updateAppWidget(widgetId, views)
                return
            } catch (t: Throwable) {
                Log.w(TAG, "update attempt $attempt failed (factor=$factor)", t)
                factor *= 0.5
            } finally {
                bitmaps.forEach { if (!it.isRecycled) it.recycle() }
            }
        }
        pushSafely(manager, widgetId, emptyViews(app, widgetId))
    }

    private fun pushSafely(manager: AppWidgetManager, widgetId: Int, views: RemoteViews) {
        try {
            manager.updateAppWidget(widgetId, views)
        } catch (t: Throwable) {
            Log.e(TAG, "updateAppWidget failed", t)
        }
    }

    // ------------------------------------------------------------ الويدجت الفارغ

    private fun emptyViews(context: Context, widgetId: Int): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_empty)
        val intent = Intent(context, WidgetConfigActivity::class.java).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val pi = PendingIntent.getActivity(
            context,
            widgetId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.root, pi)
        return views
    }

    // ------------------------------------------------------------ ويدجت الوسائط

    private fun buildMediaViews(
        context: Context,
        manager: AppWidgetManager,
        cfg: WidgetConfig,
        mod: String,
        factor: Double,
        out: MutableList<Bitmap>
    ): RemoteViews {
        val dir = WidgetStore.framesDir(context, cfg.widgetId, mod)
        val files = (0 until cfg.frameCount)
            .map { File(dir, FrameExtractor.frameName(it)) }
            .filter { it.exists() }
        if (files.isEmpty()) throw IllegalStateException("no stored frames")

        // حجم الويدجت بالبكسل
        val dm = context.resources.displayMetrics
        val options = manager.getAppWidgetOptions(cfg.widgetId)
        val wDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        val hDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        val tw = max(64f, (if (wDp > 0) wDp else 250) * dm.density)
        val th = max(64f, (if (hDp > 0) hDp else 250) * dm.density)
        val aspect = tw / th

        // أبعاد الإطار المخزّن
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(files[0].path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IllegalStateException("bad stored frame")
        }
        val cropSize = centerCrop(bounds.outWidth, bounds.outHeight, aspect)

        // نحسب أكبر دقة تتسع في ميزانية الذاكرة
        val bytesPerPixel = if (cfg.hasAlpha) 4 else 2
        val budget = 6.0 * dm.widthPixels * dm.heightPixels * factor
        var count = files.size
        var rw = 1
        var rh = 1
        while (true) {
            val pixelsPerFrame = budget / (count * bytesPerPixel)
            val w = min(
                sqrt(pixelsPerFrame * aspect),
                min(cropSize.width().toDouble(), tw.toDouble())
            )
            rw = max(1, w.toInt())
            rh = max(1, (w / aspect).toInt())
            if (rw >= MIN_RENDER_WIDTH || count <= 6) break
            count = max(6, count - 6)
        }

        val pkg = context.packageName
        val views = RemoteViews(pkg, R.layout.widget_media)
        views.removeAllViews(R.id.flipper)

        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
        val config = if (cfg.hasAlpha) Bitmap.Config.ARGB_8888 else Bitmap.Config.RGB_565
        for (file in files.take(count)) {
            val base = BitmapFactory.decodeFile(file.path) ?: continue
            val src = centerCrop(base.width, base.height, aspect)
            val frame = Bitmap.createBitmap(rw, rh, config)
            Canvas(frame).drawBitmap(base, src, Rect(0, 0, rw, rh), paint)
            base.recycle()
            out.add(frame)

            val child = RemoteViews(pkg, R.layout.widget_frame)
            child.setImageViewBitmap(R.id.frame, frame)
            views.addView(R.id.flipper, child)
        }
        if (out.isEmpty()) throw IllegalStateException("no frames rendered")

        // الاسم الاختياري
        val label = cfg.label
        if (label.isNullOrBlank()) {
            views.setViewVisibility(R.id.label, View.GONE)
        } else {
            views.setTextViewText(R.id.label, label)
            views.setViewVisibility(R.id.label, View.VISIBLE)
        }

        // الضغط يفتح التطبيق المختار (ويدجت الاختصار فقط)
        val targetPkg = cfg.appPackage
        if (targetPkg != null) {
            val launch = context.packageManager.getLaunchIntentForPackage(targetPkg)
                ?: Intent(context, MainActivity::class.java)
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(
                context,
                cfg.widgetId,
                launch,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.root, pi)
        }
        return views
    }

    /** مستطيل القص من المنتصف بنسبة الويدجت (center-crop). */
    private fun centerCrop(w: Int, h: Int, aspect: Float): Rect {
        return if (w.toFloat() / h > aspect) {
            val cw = (h * aspect).toInt().coerceIn(1, w)
            val left = (w - cw) / 2
            Rect(left, 0, left + cw, h)
        } else {
            val ch = (w / aspect).toInt().coerceIn(1, h)
            val top = (h - ch) / 2
            Rect(0, top, w, top + ch)
        }
    }
}
