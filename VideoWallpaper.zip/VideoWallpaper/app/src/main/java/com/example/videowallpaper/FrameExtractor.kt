package com.example.videowallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Movie
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * الغرض: تحويل صورة / GIF / فيديو إلى إطارات صغيرة محفوظة على القرص، لتعرضها الويدجتات
 * (الويدجت في أندرويد لا يشغّل فيديو حقيقياً، فنبني حلقة قصيرة من الإطارات بسرعة ~12.5 إطار/ث).
 *
 * يجب استدعاء extract() من خيط خلفي.
 */
object FrameExtractor {

    /** الفاصل بين إطارين (يطابق android:flipInterval في widget_media.xml). */
    const val FRAME_INTERVAL_MS = 80L

    private const val ANIM_MAX_SIDE = 480
    private const val STILL_MAX_SIDE = 1280

    /** أقصى عدد إطارات لكل مستوى جودة: أوضح / متوازن / أسلس. */
    val QUALITY_MAX_FRAMES = intArrayOf(20, 36, 60)

    data class Result(val kind: String, val frameCount: Int, val hasAlpha: Boolean)

    fun frameName(index: Int): String = String.format(Locale.US, "f%03d", index)

    fun extract(
        context: Context,
        uri: Uri,
        tempDir: File,
        quality: Int,
        onProgress: (Int) -> Unit
    ): Result {
        val maxFrames = QUALITY_MAX_FRAMES[quality.coerceIn(0, 2)]
        tempDir.deleteRecursively()
        tempDir.mkdirs()
        val mime = context.contentResolver.getType(uri).orEmpty().lowercase(Locale.US)
        return when {
            mime.startsWith("video/") -> extractVideo(context, uri, tempDir, maxFrames, onProgress)
            mime == "image/gif" -> extractGif(context, uri, tempDir, maxFrames, onProgress)
            else -> extractStill(context, uri, tempDir, onProgress)
        }
    }

    /** صورة مصغّرة للمعاينة داخل شاشة الإعداد. */
    fun thumbnail(context: Context, uri: Uri, maxSide: Int): Bitmap? = try {
        val mime = context.contentResolver.getType(uri).orEmpty().lowercase(Locale.US)
        if (mime.startsWith("video/")) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, uri)
                r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?.let { scaleDown(it, maxSide) }
            } finally {
                try {
                    r.release()
                } catch (_: Exception) {
                }
            }
        } else {
            decodeSampled(context, uri, maxSide)
        }
    } catch (e: Exception) {
        null
    }

    // ---------------------------------------------------------------- صورة ثابتة

    private fun extractStill(
        context: Context,
        uri: Uri,
        dir: File,
        onProgress: (Int) -> Unit
    ): Result {
        val decoded = decodeSampled(context, uri, STILL_MAX_SIDE)
            ?: throw IllegalStateException("cannot decode image")
        val bmp = applyExifRotation(context, uri, decoded)
        val alpha = bmp.hasAlpha()
        save(bmp, File(dir, frameName(0)), alpha)
        bmp.recycle()
        onProgress(100)
        return Result("image", 1, alpha)
    }

    // ---------------------------------------------------------------- GIF

    @Suppress("DEPRECATION")
    private fun extractGif(
        context: Context,
        uri: Uri,
        dir: File,
        maxFrames: Int,
        onProgress: (Int) -> Unit
    ): Result {
        val movie = context.contentResolver.openInputStream(uri)?.use { Movie.decodeStream(it) }
        val duration = movie?.duration() ?: 0
        if (movie == null || duration <= 0 || movie.width() <= 0 || movie.height() <= 0) {
            // GIF ثابت أو غير مدعوم: نعامله كصورة عادية
            return extractStill(context, uri, dir, onProgress)
        }

        val total = min(maxFrames.toLong(), max(1L, duration / FRAME_INTERVAL_MS)).toInt()
        val scale = min(1f, ANIM_MAX_SIDE.toFloat() / max(movie.width(), movie.height()))
        val bw = max(1, (movie.width() * scale).toInt())
        val bh = max(1, (movie.height() * scale).toInt())

        var hasAlpha = false
        for (i in 0 until total) {
            val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.scale(scale, scale)
            movie.setTime(((i * FRAME_INTERVAL_MS) % duration).toInt())
            movie.draw(canvas, 0f, 0f)
            if (i == 0) hasAlpha = containsTransparency(bmp)
            save(bmp, File(dir, frameName(i)), hasAlpha)
            bmp.recycle()
            onProgress(((i + 1) * 100) / total)
        }
        return Result("gif", total, hasAlpha)
    }

    // ---------------------------------------------------------------- فيديو

    private fun extractVideo(
        context: Context,
        uri: Uri,
        dir: File,
        maxFrames: Int,
        onProgress: (Int) -> Unit
    ): Result {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val total = min(maxFrames.toLong(), max(1L, durationMs / FRAME_INTERVAL_MS)).toInt()

            var saved = 0
            for (i in 0 until total) {
                val timeUs = i * FRAME_INTERVAL_MS * 1000L
                val raw = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if (raw != null) {
                    val bmp = scaleDown(raw, ANIM_MAX_SIDE)
                    save(bmp, File(dir, frameName(saved)), false)
                    saved++
                    bmp.recycle()
                }
                onProgress(((i + 1) * 100) / total)
            }
            if (saved == 0) throw IllegalStateException("no frames decoded")
            return Result("video", saved, false)
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }

    // ---------------------------------------------------------------- أدوات

    private fun save(bmp: Bitmap, file: File, alpha: Boolean) {
        FileOutputStream(file).use { out ->
            if (alpha) bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            else bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
    }

    private fun containsTransparency(bmp: Bitmap): Boolean {
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        return px.any { (it ushr 24) < 250 }
    }

    private fun decodeSampled(context: Context, uri: Uri, maxSide: Int): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: return null
        return scaleDown(decoded, maxSide)
    }

    private fun scaleDown(bmp: Bitmap, maxSide: Int): Bitmap {
        val longest = max(bmp.width, bmp.height)
        if (longest <= maxSide) return bmp
        val s = maxSide.toFloat() / longest
        val out = Bitmap.createScaledBitmap(
            bmp,
            max(1, (bmp.width * s).toInt()),
            max(1, (bmp.height * s).toInt()),
            true
        )
        if (out !== bmp) bmp.recycle()
        return out
    }

    @Suppress("DEPRECATION")
    private fun applyExifRotation(context: Context, uri: Uri, bmp: Bitmap): Bitmap {
        val orientation = try {
            context.contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            else -> return bmp
        }
        val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (out !== bmp) bmp.recycle()
        return out
    }
}
