package com.example.videowallpaper

import android.content.Context
import android.provider.Settings

/**
 * الغرض: إعادة رسم الويدجتات وإعادة تشغيل الخلفية الحية بعد إقلاع الجهاز.
 * بعد الإقلاع قد تبقى الخلفية سوداء والويدجتات فارغة لأنها حُمّلت قبل أن يصبح التخزين جاهزاً.
 *  - المستقبِل (ScheduleReceiver) يستدعيها عند BOOT_COMPLETED.
 *  - وكاحتياط، تستدعيها الشاشة الرئيسية عند فتح التطبيق إن لم يحدث ذلك بعد هذا الإقلاع
 *    (بعض الهواتف تمنع وصول حدث الإقلاع).
 */
object BootRefresh {

    private const val KEY_LAST_BOOT = "last_boot_count"

    private fun bootCount(context: Context): Int = try {
        Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT)
    } catch (e: Exception) {
        -1
    }

    fun refreshAll(context: Context) {
        val app = context.applicationContext
        AppLog.d(app, "Boot", "refresh widgets + wallpaper")
        ModStore.refreshWidgets(app)
        AppSettings.bumpRefreshTick(app)
        val count = bootCount(app)
        if (count >= 0) AppSettings.prefs(app).edit().putInt(KEY_LAST_BOOT, count).apply()
    }

    /** يُنفّذ إعادة الرسم مرة واحدة لكل إقلاع. يرجع true إن نفّذها. */
    fun ensure(context: Context): Boolean {
        val app = context.applicationContext
        val count = bootCount(app)
        if (count >= 0 && AppSettings.prefs(app).getInt(KEY_LAST_BOOT, -2) == count) return false
        refreshAll(app)
        return true
    }
}
