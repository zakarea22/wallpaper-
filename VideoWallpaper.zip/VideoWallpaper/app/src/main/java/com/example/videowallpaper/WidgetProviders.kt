package com.example.videowallpaper

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.Context
import android.os.Bundle
import android.util.Log

/**
 * الغرض: استقبال أحداث الويدجت (تحديث، تغيير الحجم، حذف) وإعادة رسمها في خيط خلفي.
 */
abstract class BaseWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        refresh(context, appWidgetManager, appWidgetIds)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        refresh(context, appWidgetManager, intArrayOf(appWidgetId))
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { WidgetStore.delete(context, it) }
    }

    private fun refresh(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending: BroadcastReceiver.PendingResult? = goAsync()
        val app = context.applicationContext
        Thread {
            try {
                ids.forEach { WidgetRenderer.update(app, manager, it) }
            } catch (t: Throwable) {
                Log.e("WidgetProvider", "refresh failed", t)
            } finally {
                pending?.finish()
            }
        }.start()
    }
}

/** ويدجت الوسائط المتحركة (صورة / GIF / فيديو بدون إجراء عند الضغط). */
class MediaWidgetProvider : BaseWidgetProvider()

/** ويدجت اختصار تطبيق: يعرض وسائط ويفتح التطبيق المختار عند الضغط. */
class ShortcutWidgetProvider : BaseWidgetProvider()
