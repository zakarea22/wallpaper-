package com.example.videowallpaper

import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * الغرض: النقطة الرئيسية للتطبيق «واجهات متحركة»:
 *  - الشاشة الرئيسية بخيارين: تخصيص واجهة متحركة (خلفية حية)، وويدجتات متحركة.
 *  - إدارة قائمة الفيديوهات (مع إعادة التسمية وتأكيد الحذف).
 *  - إدارة الويدجتات الموضوعة على الشاشة.
 */
class MainActivity : ComponentActivity() {

    // يزداد عند كل رجوع للتطبيق (لتحديث قائمة الويدجتات بعد الإعداد)
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                AppRoot(resumeTick.intValue)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }
}

private enum class Screen { HOME, WALLPAPERS, WIDGETS, MODS, SETTINGS }

private const val MAX_NAME_LENGTH = 40

@Composable
private fun AppRoot(resumeTick: Int) {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }

    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    when (screen) {
        Screen.HOME -> HomeScreen(
            resumeTick = resumeTick,
            onWallpapers = { screen = Screen.WALLPAPERS },
            onWidgets = { screen = Screen.WIDGETS },
            onMods = { screen = Screen.MODS },
            onSettings = { screen = Screen.SETTINGS }
        )
        Screen.SETTINGS -> SettingsScreen(onBack = { screen = Screen.HOME })
        Screen.WALLPAPERS -> WallpapersScreen(onBack = { screen = Screen.HOME })
        Screen.WIDGETS -> WidgetsScreen(resumeTick = resumeTick, onBack = { screen = Screen.HOME })
        Screen.MODS -> ModsScreen(resumeTick = resumeTick, onBack = { screen = Screen.HOME })
    }
}

// ====================================================================== الرئيسية

@Composable
private fun HomeScreen(
    resumeTick: Int,
    onWallpapers: () -> Unit,
    onWidgets: () -> Unit,
    onMods: () -> Unit,
    onSettings: () -> Unit
) {
    val context = LocalContext.current
    val mods = remember(resumeTick) { ModStore.list(context) }
    val activeName = remember(resumeTick) { ModStore.active(context).name }
    val videosCount = remember(resumeTick) { WallpaperPrefs(context).getAllVideos().size }

    // علامات الإنجاز في الدليل (الخطوتان 4 و5 إرشاديتان فقط)
    val step1Done = videosCount >= 1
    val step2Done = mods.size >= 2
    val step3Done = mods.mapNotNull { it.wallpaper }.toSet().size >= 2

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(72.dp))
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Light,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(36.dp))

        Row(
            modifier = Modifier.height(IntrinsicSize.Min),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SmallHomeCard(
                icon = Icons.Default.Widgets,
                title = stringResource(R.string.home_widgets_title),
                note = stringResource(R.string.home_widgets_note),
                onClick = onWidgets,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )
            SmallHomeCard(
                icon = Icons.Default.Wallpaper,
                title = stringResource(R.string.home_wallpaper_title),
                note = stringResource(R.string.home_wallpaper_note),
                onClick = onWallpapers,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )
        }

        Spacer(Modifier.height(14.dp))
        FeaturedModsCard(activeName = activeName, onClick = onMods)

        Spacer(Modifier.height(20.dp))
        GuideCard(
            step1Done = step1Done,
            step2Done = step2Done,
            step3Done = step3Done,
            onWallpapers = onWallpapers,
            onMods = onMods
        )
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
            Text(
                text = stringResource(R.string.home_settings_button),
                modifier = Modifier.padding(start = 8.dp)
            )
        }
        LogExportButton()
        Spacer(Modifier.height(32.dp))
    }
}

/** زر تصدير سجل الأحداث: يفتح منتقي ملفات النظام ليختار المستخدم مكان الحفظ. */
@Composable
private fun LogExportButton() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { AppLog.exportTo(context, uri) }
                Toast.makeText(
                    context,
                    context.getString(if (ok) R.string.log_export_done else R.string.log_export_failed),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
    TextButton(
        onClick = { launcher.launch("more-screen-moving-log.txt") },
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = stringResource(R.string.log_export_button),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun SmallHomeCard(
    icon: ImageVector,
    title: String,
    note: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(modifier = Modifier.padding(14.dp)) {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(26.dp)
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 12.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = note,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun FeaturedModsCard(activeName: String, onClick: () -> Unit) {
    val prefix = stringResource(R.string.home_mods_active_prefix)
    val note = stringResource(R.string.home_mods_note)
    val highlight = MaterialTheme.colorScheme.secondary
    val text = buildAnnotatedString {
        append(prefix)
        withStyle(SpanStyle(color = highlight, fontWeight = FontWeight.Medium)) { append(activeName) }
        append(". ")
        append(note)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 28.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Palette,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(52.dp)
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 24.dp)
            ) {
                Text(
                    text = stringResource(R.string.home_mods_title),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Light,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = text,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Normal,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

/** دليل الاستخدام: خمس خطوات، تُعلَّم بـ ✓ عند إنجازها، ويمكن طيّه. */
@Composable
private fun GuideCard(
    step1Done: Boolean,
    step2Done: Boolean,
    step3Done: Boolean,
    onWallpapers: () -> Unit,
    onMods: () -> Unit
) {
    var expanded by rememberSaveable { mutableStateOf(true) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically
            ) {
                PlusBadge()
                Text(
                    text = stringResource(R.string.guide_title),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp)
                )
                Icon(
                    if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (expanded) {
                Spacer(Modifier.height(8.dp))
                GuideStep(1, stringResource(R.string.guide_step1), step1Done, onWallpapers)
                GuideStep(2, stringResource(R.string.guide_step2), step2Done, onMods)
                GuideStep(3, stringResource(R.string.guide_step3), step3Done, onMods)
                GuideStep(4, stringResource(R.string.guide_step4), null, onMods)
                GuideStep(5, stringResource(R.string.guide_step5), null, null)
            }
        }
    }
}

@Composable
private fun GuideStep(number: Int, text: String, done: Boolean?, onClick: (() -> Unit)?) {
    val rowModifier = Modifier
        .fillMaxWidth()
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }
        .padding(vertical = 8.dp)

    Row(modifier = rowModifier, verticalAlignment = Alignment.Top) {
        val green = MaterialTheme.colorScheme.primary
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(if (done == true) green else Color.Transparent)
                .border(1.dp, if (done == true) green else MaterialTheme.colorScheme.outline, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (done == true) {
                Icon(
                    Icons.Default.Check,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(18.dp)
                )
            } else {
                Text(
                    text = number.toString(),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier
                .weight(1f)
                .padding(start = 12.dp, top = 3.dp)
        )
    }
}

// ====================================================================== الخلفيات

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WallpapersScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { WallpaperPrefs(context) }
    val videos = remember { mutableStateListOf<Uri>().apply { addAll(prefs.getAllVideos()) } }
    val names = remember {
        mutableStateMapOf<Uri, String>().apply {
            prefs.getAllEntries().forEach { e -> e.name?.let { put(e.uri, it) } }
        }
    }
    var activeUri by remember { mutableStateOf(prefs.getActiveVideo()) }
    var pendingDelete by remember { mutableStateOf<Uri?>(null) }

    val pickLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            context.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            prefs.addVideo(uri)
            if (!videos.contains(uri)) videos.add(uri)
        } catch (e: SecurityException) {
            Toast.makeText(context, R.string.err_permission, Toast.LENGTH_LONG).show()
        }
    }

    fun performDelete(uri: Uri) {
        prefs.removeVideo(uri)
        ModStore.clearWallpaper(context, uri)
        videos.remove(uri)
        names.remove(uri)
        if (activeUri == uri) activeUri = null
        try {
            context.contentResolver.releasePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = { Text(stringResource(R.string.wallpapers_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { pickLauncher.launch(arrayOf("video/*")) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.add_video))
            }
        }
    ) { padding ->
        if (videos.isEmpty()) {
            EmptyState(
                modifier = Modifier.padding(padding),
                onAdd = { pickLauncher.launch(arrayOf("video/*")) }
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(videos, key = { it.toString() }) { uri ->
                    VideoItem(
                        uri = uri,
                        customName = names[uri],
                        isActive = uri == activeUri,
                        onSetWallpaper = {
                            prefs.setActiveVideo(uri)
                            ModStore.setWallpaper(context, ModStore.activeId(context), uri)
                            activeUri = uri
                            launchWallpaperPicker(context)
                        },
                        onRename = { newName ->
                            prefs.setName(uri, newName)
                            val clean = newName.trim()
                            if (clean.isEmpty()) names.remove(uri) else names[uri] = clean
                        },
                        onDelete = { pendingDelete = uri }
                    )
                }
            }
        }
    }

    pendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(stringResource(R.string.delete_confirm_title)) },
            text = { Text(stringResource(R.string.delete_confirm_message)) },
            confirmButton = {
                TextButton(onClick = {
                    performDelete(target)
                    pendingDelete = null
                }) {
                    Text(stringResource(R.string.delete_confirm_button))
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

@Composable
private fun VideoItem(
    uri: Uri,
    customName: String?,
    isActive: Boolean,
    onSetWallpaper: () -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val fileName by produceState(initialValue = uri.lastPathSegment ?: uri.toString(), uri) {
        val name = withContext(Dispatchers.IO) {
            runCatching { DocumentFile.fromSingleUri(context, uri)?.name }.getOrNull()
        }
        if (!name.isNullOrEmpty()) value = name
    }
    val title = customName ?: fileName
    var showRename by remember { mutableStateOf(false) }

    if (showRename) {
        RenameDialog(
            initial = title,
            onConfirm = { newName ->
                onRename(newName)
                showRename = false
            },
            onDismiss = { showRename = false }
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant
        ),
        border = if (isActive) BorderStroke(1.dp, MaterialTheme.colorScheme.outline) else null
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Movie,
                    contentDescription = stringResource(R.string.video_icon),
                    modifier = Modifier.size(32.dp)
                )
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (isActive) {
                        Text(
                            text = stringResource(R.string.active_label),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                IconButton(onClick = { showRename = true }) {
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = stringResource(R.string.rename_video)
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = stringResource(R.string.delete_video)
                    )
                }
            }
            TextButton(onClick = onSetWallpaper) {
                Icon(Icons.Default.Wallpaper, contentDescription = null)
                Text(
                    text = stringResource(R.string.set_as_wallpaper),
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun RenameDialog(
    initial: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var draft by remember { mutableStateOf(initial.take(MAX_NAME_LENGTH)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.rename_title)) },
        text = {
            Column {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { if (it.length <= MAX_NAME_LENGTH) draft = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.name_hint)) }
                )
                Text(
                    text = stringResource(R.string.name_reset_hint),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(draft) }) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

@Composable
private fun EmptyState(modifier: Modifier = Modifier, onAdd: () -> Unit) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.Movie,
            contentDescription = null,
            modifier = Modifier.size(96.dp),
            tint = MaterialTheme.colorScheme.outline
        )
        Text(
            text = stringResource(R.string.empty_title),
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(top = 16.dp),
            textAlign = TextAlign.Center
        )
        Text(
            text = stringResource(R.string.empty_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
            textAlign = TextAlign.Center
        )
        Button(onClick = onAdd, modifier = Modifier.padding(top = 24.dp)) {
            Icon(Icons.Default.Add, contentDescription = null)
            Text(
                text = stringResource(R.string.empty_add_button),
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}

private fun launchWallpaperPicker(context: Context) {
    val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
        putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(context, VideoWallpaperService::class.java)
        )
    }
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        // بديل: منتقي الخلفيات الحية العام
        try {
            context.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        } catch (e2: ActivityNotFoundException) {
            Toast.makeText(context, R.string.err_no_wallpaper_app, Toast.LENGTH_LONG).show()
        }
    }
}

// ====================================================================== الويدجتات

private data class WidgetRowData(
    val id: Int,
    val isShortcut: Boolean,
    val cfg: WidgetConfig?,
    val thumb: ImageBitmap?,
    val appLabel: String?,
    val hidden: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WidgetsScreen(resumeTick: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    var localTick by remember { mutableIntStateOf(0) }
    val rows = remember(resumeTick, localTick) { loadWidgetRows(context) }

    Scaffold(
        topBar = {
            AppTopBar(
                title = { Text(stringResource(R.string.widgets_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Button(
                    onClick = { requestPin(context, MediaWidgetProvider::class.java) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Text(
                        text = stringResource(R.string.widgets_add_media),
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
            item {
                Button(
                    onClick = { requestPin(context, ShortcutWidgetProvider::class.java) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Text(
                        text = stringResource(R.string.widgets_add_shortcut),
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
            item {
                Button(
                    onClick = { requestPin(context, ModSwitchWidgetProvider::class.java) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Text(
                        text = stringResource(R.string.widgets_add_switcher),
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
            item {
                Text(
                    text = stringResource(R.string.widgets_howto),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                Text(
                    text = stringResource(R.string.widgets_mod_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                Text(
                    text = stringResource(R.string.widgets_placed),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            if (rows.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.widgets_none),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(rows, key = { it.id }) { row ->
                    WidgetRowCard(
                        row = row,
                        onEdit = {
                            context.startActivity(
                                Intent(context, WidgetConfigActivity::class.java)
                                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, row.id)
                            )
                        },
                        onToggleHidden = {
                            WidgetStore.setHidden(context, row.id, !row.hidden)
                            val app = context.applicationContext
                            Thread { WidgetRenderer.update(app, row.id) }.start()
                            localTick++
                        },
                        onClear = {
                            WidgetStore.delete(context, row.id)
                            val app = context.applicationContext
                            Thread { WidgetRenderer.update(app, row.id) }.start()
                            localTick++
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun WidgetRowCard(
    row: WidgetRowData,
    onEdit: () -> Unit,
    onToggleHidden: () -> Unit,
    onClear: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val thumb = row.thumb
            if (thumb != null) {
                Image(
                    bitmap = thumb,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
            } else {
                Icon(Icons.Default.Widgets, contentDescription = null, modifier = Modifier.size(56.dp))
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                Text(
                    text = stringResource(
                        if (row.isShortcut) R.string.widget_kind_shortcut else R.string.widget_kind_media
                    ),
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = if (row.hidden) stringResource(R.string.widget_status_hidden)
                    else if (row.cfg == null) stringResource(R.string.widget_status_empty)
                    else row.appLabel ?: row.cfg.label.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onToggleHidden) {
                Icon(
                    if (row.hidden) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = stringResource(
                        if (row.hidden) R.string.widget_show else R.string.widget_hide
                    )
                )
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.widget_edit))
            }
            if (row.cfg != null) {
                IconButton(onClick = onClear) {
                    Icon(Icons.Default.Clear, contentDescription = stringResource(R.string.widget_clear))
                }
            }
        }
    }
}

private fun loadWidgetRows(context: Context): List<WidgetRowData> {
    val manager = AppWidgetManager.getInstance(context)
    val pm = context.packageManager
    val rows = mutableListOf<WidgetRowData>()

    fun collect(providerClass: Class<*>, isShortcut: Boolean) {
        manager.getAppWidgetIds(ComponentName(context, providerClass)).forEach { id ->
            val cfg = WidgetStore.get(context, id)
            val thumb = if (cfg != null) loadFirstFrame(context, id) else null
            val appLabel = cfg?.appPackage?.let { pkg ->
                try {
                    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                } catch (e: Exception) {
                    pkg
                }
            }
            rows.add(WidgetRowData(id, isShortcut, cfg, thumb, appLabel, WidgetStore.isHidden(context, id)))
        }
    }
    collect(MediaWidgetProvider::class.java, false)
    collect(ShortcutWidgetProvider::class.java, true)
    return rows
}

private fun loadFirstFrame(context: Context, widgetId: Int): ImageBitmap? {
    val file = File(WidgetStore.framesDir(context, widgetId), FrameExtractor.frameName(0))
    if (!file.exists()) return null
    val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
    return BitmapFactory.decodeFile(file.path, opts)?.asImageBitmap()
}

private fun requestPin(context: Context, providerClass: Class<*>) {
    val manager = AppWidgetManager.getInstance(context)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.isRequestPinAppWidgetSupported) {
        manager.requestPinAppWidget(ComponentName(context, providerClass), null, null)
    } else {
        Toast.makeText(
            context,
            context.getString(R.string.widgets_pin_unsupported, context.getString(R.string.app_name)),
            Toast.LENGTH_LONG
        ).show()
    }
}
