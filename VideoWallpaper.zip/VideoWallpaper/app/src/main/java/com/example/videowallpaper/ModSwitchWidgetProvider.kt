package com.example.videowallpaper

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.View
import android.widget.RemoteViews

/**
 * الغرض: ويدجت يعرض صورة الوضع النشط واسمه؛ الضغط عليه ينتقل للوضع التالي.
 * خفيف جداً: صورة مصغرة 256px فقط، ويُحدَّث مع كل تبديل من أي مكان (الزر السريع، التطبيق، الجدولة).
 */
class ModSwitchWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { ModSwitchWidget.update(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_NEXT) {
            val app = context.applicationContext
            val pending = goAsync()
            Thread {
                try {
                    ModStore.apply(app, ModStore.next(app).id)
                    ModStore.awaitRefresh()
                } catch (t: Throwable) {
                    Log.w("ModSwitchWidget", "switch failed", t)
                } finally {
                    pending.finish()
                }
            }.start()
            return
        }
        super.onReceive(context, intent)
    }

    companion object {
        const val ACTION_NEXT = "com.example.videowallpaper.MOD_SWITCH_NEXT"
    }
}

object ModSwitchWidget {

    fun updateAll(context: Context) {
        val app = context.applicationContext
        val manager = AppWidgetManager.getInstance(app)
        manager.getAppWidgetIds(ComponentName(app, ModSwitchWidgetProvider::class.java))
            .forEach { update(app, manager, it) }
    }

    fun update(context: Context, manager: AppWidgetManager, widgetId: Int) {
        val app = context.applicationContext
        val mod = ModStore.active(app)
        val views = RemoteViews(app.packageName, R.layout.widget_mod_switch)
        views.setTextViewText(R.id.mod_name, mod.name)

        val thumb = ModStore.loadThumb(app, mod)
        if (thumb != null) {
            views.setImageViewBitmap(R.id.mod_thumb, thumb)
            views.setViewVisibility(R.id.mod_thumb, View.VISIBLE)
        } else {
            views.setViewVisibility(R.id.mod_thumb, View.GONE)
        }

        val pi = PendingIntent.getBroadcast(
            app,
            0,
            Intent(app, ModSwitchWidgetProvider::class.java).setAction(ModSwitchWidgetProvider.ACTION_NEXT),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.root, pi)
        try {
            manager.updateAppWidget(widgetId, views)
        } catch (t: Throwable) {
            Log.w("ModSwitchWidget", "update failed", t)
        }
    }
}
