package com.example.videowallpaper

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import java.util.Locale

/**
 * الغرض: شاشة الإعدادات العامة (تنطبق على كل الأوضاع):
 * توفير البطارية، التحكم بالفيديو، شكل الويدجتات، والتبديل التلقائي بالساعة.
 * كل تغيير يُحفظ فوراً في AppSettings، والخلفية والويدجتات تلتقطه مباشرة.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext

    var saverOn by remember { mutableStateOf(AppSettings.saverEnabled(context)) }
    var threshold by remember { mutableIntStateOf(AppSettings.saverThreshold(context)) }
    var speedIndex by remember {
        mutableIntStateOf(AppSettings.SPEEDS.indexOf(AppSettings.speed(context)).takeIf { it >= 0 } ?: 2)
    }
    var fit by remember { mutableStateOf(AppSettings.fit(context)) }
    var shape by remember { mutableIntStateOf(AppSettings.shapeIndex(context)) }
    var border by remember { mutableIntStateOf(AppSettings.borderIndex(context)) }

    var schedOn by remember { mutableStateOf(AppSettings.schedEnabled(context)) }
    var dayMod by remember { mutableStateOf(AppSettings.schedDayMod(context)) }
    var nightMod by remember { mutableStateOf(AppSettings.schedNightMod(context)) }
    var dayHour by remember { mutableIntStateOf(AppSettings.schedDayHour(context)) }
    var nightHour by remember { mutableIntStateOf(AppSettings.schedNightHour(context)) }
    var picking by remember { mutableStateOf<String?>(null) } // "day" أو "night"

    val mods = remember { ModStore.list(context) }

    fun modName(id: String?): String =
        mods.firstOrNull { it.id == id }?.name ?: context.getString(R.string.schedule_not_set)

    /** يحفظ الجدول ويعيد ضبط المنبّه ويطبّق وضع الفترة الحالية فوراً. */
    fun scheduleChanged() {
        Thread {
            Scheduler.rearm(app)
            Scheduler.applyNow(app)
        }.start()
    }

    fun restyleWidgets() = ModStore.refreshWidgets(app)

    Scaffold(
        topBar = {
            AppTopBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ------------------------------------------------ توفير البطارية
            SettingsCard(stringResource(R.string.settings_section_battery)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.settings_saver_switch),
                        modifier = Modifier.weight(1f)
                    )
                    Switch(checked = saverOn, onCheckedChange = {
                        saverOn = it
                        AppSettings.setSaverEnabled(context, it)
                    })
                }
                Note(stringResource(R.string.settings_saver_note))
                if (saverOn) {
                    Label(stringResource(R.string.settings_saver_threshold))
                    ChipRow(
                        options = AppSettings.SAVER_THRESHOLDS.map { "$it%" },
                        selected = AppSettings.SAVER_THRESHOLDS.indexOf(threshold),
                        onSelect = {
                            threshold = AppSettings.SAVER_THRESHOLDS[it]
                            AppSettings.setSaverThreshold(context, threshold)
                        }
                    )
                }
            }

            // ------------------------------------------------ الفيديو
            SettingsCard(stringResource(R.string.settings_section_video)) {
                Label(stringResource(R.string.settings_speed))
                ChipRow(
                    options = AppSettings.SPEEDS.map {
                        String.format(Locale.US, "%sx", if (it % 1f == 0f) it.toInt().toString() else it.toString())
                    },
                    selected = speedIndex,
                    onSelect = {
                        speedIndex = it
                        AppSettings.setSpeed(context, AppSettings.SPEEDS[it])
                    }
                )
                Label(stringResource(R.string.settings_fit_label))
                ChipRow(
                    options = listOf(
                        stringResource(R.string.settings_fit_crop),
                        stringResource(R.string.settings_fit_contain)
                    ),
                    selected = if (fit) 1 else 0,
                    onSelect = {
                        fit = it == 1
                        AppSettings.setFit(context, fit)
                    }
                )
            }

            // ------------------------------------------------ شكل الويدجتات
            SettingsCard(stringResource(R.string.settings_section_widgets)) {
                Label(stringResource(R.string.settings_shape))
                ChipRow(
                    options = listOf(
                        stringResource(R.string.shape_none),
                        stringResource(R.string.shape_light),
                        stringResource(R.string.shape_medium),
                        stringResource(R.string.shape_large),
                        stringResource(R.string.shape_circle)
                    ),
                    selected = shape,
                    onSelect = {
                        shape = it
                        AppSettings.setShapeIndex(context, it)
                        restyleWidgets()
                    }
                )
                Label(stringResource(R.string.settings_border))
                ChipRow(
                    options = listOf(
                        stringResource(R.string.border_none),
                        stringResource(R.string.border_white),
                        stringResource(R.string.border_green)
                    ),
                    selected = border,
                    onSelect = {
                        border = it
                        AppSettings.setBorderIndex(context, it)
                        restyleWidgets()
                    }
                )
                Note(stringResource(R.string.settings_widgets_note))
            }

            // ------------------------------------------------ التبديل التلقائي
            SettingsCard(stringResource(R.string.settings_section_schedule)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.schedule_switch),
                        modifier = Modifier.weight(1f)
                    )
                    Switch(checked = schedOn, onCheckedChange = { on ->
                        schedOn = on
                        if (on) {
                            // اختيار افتراضي معقول عند أول تفعيل
                            if (dayMod == null && mods.isNotEmpty()) {
                                dayMod = mods.first().id
                                AppSettings.setSchedDayMod(context, dayMod!!)
                            }
                            if (nightMod == null && mods.isNotEmpty()) {
                                nightMod = (mods.getOrNull(1) ?: mods.first()).id
                                AppSettings.setSchedNightMod(context, nightMod!!)
                            }
                        }
                        AppSettings.setSchedEnabled(context, on)
                        scheduleChanged()
                    })
                }
                Note(stringResource(R.string.schedule_note))
                if (schedOn) {
                    Label(stringResource(R.string.schedule_day_mod))
                    OutlinedButton(
                        onClick = { picking = "day" },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(modName(dayMod)) }
                    HourStepper(
                        label = stringResource(R.string.schedule_day_from),
                        hour = dayHour,
                        onChange = {
                            dayHour = it
                            AppSettings.setSchedDayHour(context, it)
                            scheduleChanged()
                        }
                    )
                    Label(stringResource(R.string.schedule_night_mod))
                    OutlinedButton(
                        onClick = { picking = "night" },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(modName(nightMod)) }
                    HourStepper(
                        label = stringResource(R.string.schedule_night_from),
                        hour = nightHour,
                        onChange = {
                            nightHour = it
                            AppSettings.setSchedNightHour(context, it)
                            scheduleChanged()
                        }
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    picking?.let { which ->
        AlertDialog(
            onDismissRequest = { picking = null },
            title = { Text(stringResource(R.string.schedule_pick_mod)) },
            text = {
                Column {
                    mods.forEach { mod ->
                        Text(
                            text = mod.name,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (which == "day") {
                                        dayMod = mod.id
                                        AppSettings.setSchedDayMod(context, mod.id)
                                    } else {
                                        nightMod = mod.id
                                        AppSettings.setSchedNightMod(context, mod.id)
                                    }
                                    picking = null
                                    scheduleChanged()
                                }
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { picking = null }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            content()
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(text = text, style = MaterialTheme.typography.bodyMedium)
}

@Composable
private fun Note(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEachIndexed { index, text ->
            FilterChip(
                selected = index == selected,
                onClick = { onSelect(index) },
                label = { Text(text) }
            )
        }
    }
}

@Composable
private fun HourStepper(label: String, hour: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text = label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        IconButton(onClick = { onChange((hour + 23) % 24) }) {
            Icon(Icons.Default.Remove, contentDescription = null)
        }
        Text(
            text = String.format(Locale.US, "%02d:00", hour),
            style = MaterialTheme.typography.titleMedium
        )
        IconButton(onClick = { onChange((hour + 1) % 24) }) {
            Icon(Icons.Default.Add, contentDescription = null)
        }
    }
}
