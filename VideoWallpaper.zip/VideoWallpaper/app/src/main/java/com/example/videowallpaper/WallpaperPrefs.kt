package com.example.videowallpaper

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/**
 * الغرض: تخزين قائمة الفيديوهات (بترتيب الإضافة) مع أسمائها المخصصة والفيديو النشط
 * في SharedPreferences. القائمة تُحفظ كـ JSONArray من JSONObject لضمان الترتيب.
 * الإدخالات القديمة (بدون اسم) تبقى متوافقة.
 */
class WallpaperPrefs(context: Context) {

    /** عنصر في القائمة: الـ URI مع اسم مخصص اختياري. */
    data class Entry(val uri: Uri, val name: String?)

    // applicationContext لتجنب تسريب الـ Activity/Service
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** يضيف فيديو إلى نهاية القائمة إن لم يكن موجوداً. */
    @Synchronized
    fun addVideo(uri: Uri) {
        val list = getAllEntries().toMutableList()
        if (list.none { it.uri == uri }) {
            list.add(Entry(uri, null))
            saveEntries(list)
        }
    }

    /** يحذف فيديو من القائمة، ويمسح الفيديو النشط إن كان هو نفسه. */
    @Synchronized
    fun removeVideo(uri: Uri) {
        val list = getAllEntries().toMutableList()
        if (list.removeAll { it.uri == uri }) saveEntries(list)
        if (getActiveVideo() == uri) {
            prefs.edit().remove(KEY_ACTIVE).apply()
        }
    }

    /** يعيد كل الفيديوهات بترتيب الإضافة. */
    @Synchronized
    fun getAllVideos(): List<Uri> = getAllEntries().map { it.uri }

    /** يعيد كل العناصر (URI + الاسم المخصص) بترتيب الإضافة. */
    @Synchronized
    fun getAllEntries(): List<Entry> {
        val raw = prefs.getString(KEY_VIDEOS, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    val s = obj.optString(FIELD_URI)
                    if (s.isEmpty()) continue
                    val name = obj.optString(FIELD_NAME).takeIf { it.isNotEmpty() }
                    add(Entry(Uri.parse(s), name))
                }
            }
        } catch (e: JSONException) {
            emptyList()
        }
    }

    /** يعيد الاسم المخصص للفيديو أو null إن لم يُسمَّ. */
    @Synchronized
    fun getName(uri: Uri): String? = getAllEntries().firstOrNull { it.uri == uri }?.name

    /** يعيّن اسماً مخصصاً. إن كان الاسم فارغاً يُمسح ويعود العرض لاسم الملف. */
    @Synchronized
    fun setName(uri: Uri, name: String?) {
        val clean = name?.trim()?.takeIf { it.isNotEmpty() }
        saveEntries(getAllEntries().map { if (it.uri == uri) it.copy(name = clean) else it })
    }

    /** يعيّن الفيديو النشط. */
    fun setActiveVideo(uri: Uri) {
        prefs.edit().putString(KEY_ACTIVE, uri.toString()).apply()
    }

    /** يعيد الفيديو النشط أو null. */
    fun getActiveVideo(): Uri? {
        val s = prefs.getString(KEY_ACTIVE, null)
        return if (s.isNullOrEmpty()) null else Uri.parse(s)
    }

    /** تسجيل مستمع لتغيّر القيم (تستخدمه الخدمة لإعادة التحميل عند تغيير الفيديو). */
    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    private fun saveEntries(list: List<Entry>) {
        val array = JSONArray()
        list.forEach { e ->
            val obj = JSONObject().put(FIELD_URI, e.uri.toString())
            if (e.name != null) obj.put(FIELD_NAME, e.name)
            array.put(obj)
        }
        prefs.edit().putString(KEY_VIDEOS, array.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "video_wallpaper_prefs"
        private const val KEY_VIDEOS = "videos_json"
        const val KEY_ACTIVE = "active_video"
        private const val FIELD_URI = "uri"
        private const val FIELD_NAME = "name"
    }
}
