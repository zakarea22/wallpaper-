package com.example.videowallpaper

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/**
 * الغرض: تخزين قائمة الفيديوهات (بترتيب الإضافة) والفيديو النشط في SharedPreferences.
 * القائمة تُحفظ كـ JSONArray من JSONObject لضمان الترتيب.
 */
class WallpaperPrefs(context: Context) {

    // applicationContext لتجنب تسريب الـ Activity/Service
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** يضيف فيديو إلى نهاية القائمة إن لم يكن موجوداً. */
    @Synchronized
    fun addVideo(uri: Uri) {
        val list = getAllVideos().toMutableList()
        if (list.none { it == uri }) {
            list.add(uri)
            saveVideos(list)
        }
    }

    /** يحذف فيديو من القائمة، ويمسح الفيديو النشط إن كان هو نفسه. */
    @Synchronized
    fun removeVideo(uri: Uri) {
        val list = getAllVideos().toMutableList()
        if (list.remove(uri)) saveVideos(list)
        if (getActiveVideo() == uri) {
            prefs.edit().remove(KEY_ACTIVE).apply()
        }
    }

    /** يعيد كل الفيديوهات بترتيب الإضافة. */
    @Synchronized
    fun getAllVideos(): List<Uri> {
        val raw = prefs.getString(KEY_VIDEOS, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val s = array.optJSONObject(i)?.optString(FIELD_URI).orEmpty()
                    if (s.isNotEmpty()) add(Uri.parse(s))
                }
            }
        } catch (e: JSONException) {
            emptyList()
        }
    }

    /** يعيّن الفيديو النشط. */
    fun setActiveVideo(uri: Uri) {
        prefs.edit().putString(KEY_ACTIVE, uri.toString()).apply()
    }

    /** يعيد الفيديو النشط أو null. */
    fun getActiveVideo(): Uri? {
        val s = prefs.getString(KEY_ACTIVE, null)
        return if (s.isNullOrEmpty()) null else Uri.parse(s)
    }

    /** تسجيل مستمع لتغيّر القيم (تستخدمه الخدمة لإعادة التحميل عند تغيير الفيديو). */
    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    private fun saveVideos(list: List<Uri>) {
        val array = JSONArray()
        list.forEach { array.put(JSONObject().put(FIELD_URI, it.toString())) }
        prefs.edit().putString(KEY_VIDEOS, array.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "video_wallpaper_prefs"
        private const val KEY_VIDEOS = "videos_json"
        const val KEY_ACTIVE = "active_video"
        private const val FIELD_URI = "uri"
    }
}
