#!/usr/bin/env bash
# Used by GitHub Actions: builds a signed release APK when the signing secrets exist,
# otherwise falls back to a debug APK so the build never breaks.
set -euo pipefail
cd "$(dirname "$0")"
if [ -n "${KEYSTORE_B64:-}" ] && [ -n "${KEYSTORE_PASSWORD:-}" ]; then
  echo "$KEYSTORE_B64" | base64 -d > "$RUNNER_TEMP/release.jks"
  export KEYSTORE_PATH="$RUNNER_TEMP/release.jks"
  echo "Building signed release APK"
  gradle assembleRelease --no-daemon
else
  echo "No signing secrets found - building debug APK"
  gradle assembleDebug --no-daemon
fi
